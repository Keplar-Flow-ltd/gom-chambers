# Source assets (provenance)

These are the **provided** assets from the attached design package
(`gaia-client-library-2026-09-19.zip`), kept here unchanged for reference and
provenance. The v2 kit in the parent folder supersedes them with the unified,
reproducible brand system.

- `covers/` — the 5 supplied photographic covers (3000×1200 JPG).
- `charts/` — the 3 supplied chart mockups (PNG).
- `palette/` — the supplied colour-system card (PNG).
- `docs/` — the supplied project documents (brief, state-of-work, video script,
  demo-day pack) from which copy and numbers were preserved.

All figures reproduced in the v2 assets come from the frozen dummy baseline in
`docs/STATE-OF-WORK.md` §2.1 / §3.
