# Pre-Session Checklist — Client Demo & Handover

**Owner legend:** [KF] Keplar Flow (Adebayo/GAIA) · [GC] Gom Chambers (Gom/PA)

## A. Before the email goes out [KF]
- [ ] A1 Session date confirmed with Gom's assistant; Meet link created (record consent noted)
- [ ] A2 Staging demo dry-run completed end-to-end using DEMO-SCRIPT.md (no wrong numbers)
- [ ] A3 Phone ready for the Field-portal demo (logged into the workspace account)
- [ ] A4 Session pack printed/second-screened: SESSION-PLAN · DEMO-SCRIPT · PA protocol · UAT checklist
- [ ] A5 Recap-email template drafted (fill numbers same day)

## B. For Gom — the pre-created Pro account (attach to the email or send right after) [GC]
> *Suggested wording for Master's email appendix:*
- [ ] B1 Create a new Google account for the firm's Notion admin (e.g., admin@gomchambers…)
- [ ] B2 Sign up at notion.so with it → choose **Notion Pro (Plus)** — 1 seat is enough to start
      (billing owned and controlled by Gom Chambers; Keplar never holds billing)
- [ ] B3 In that workspace: Settings → Members → invite **adebayo@keplarflow.com** as **Admin**
      (not owner — Gom's account stays the single owner, per Agreement §3.2)
- [ ] B4 (Day of session, 10 min before) Gom clicks the OAuth consent link Keplar sends —
      authorizes the GAIA integration on the **new workspace**, selecting "All pages"

## C. On our side for prod [KF]
- [ ] C1 Fresh MCP OAuth authorize URL generated for the session (client registration persists;
      new consent = one click) + listener armed
- [ ] C2 `build_production.py` reviewed; config title set to the prod root name
- [ ] C3 Tokens/steps for the prod run rehearsed against staging (dry-run mode)
- [ ] C4 This machine online + bridges alive; ngrok pair applied if available (nice-to-have)

## D. Session-day, 30 minutes before [KF]
- [ ] D1 Staging spot-check: P-014 reset to Pending Verification; queues show 745k/1,045k
- [ ] D2 Field form test row cleaned; K-queues tidy
- [ ] D3 Calendar/timeline views open without quota warnings; Notion AI quota confirmed
- [ ] D4 Prod invite accepted; workspace reachable (post-B3)
- [ ] D5 Demo order rehearsed top-3 stops once

## E. After the session [KF]
- [ ] E1 Recap email same day: what was demoed, decisions, open items (§3.5 vs §7 classified)
- [ ] E2 If §3.3 authorization given in writing: schedule live-data intake kickoff with the PA
- [ ] E3 Prod build log started; UAT checklist running against prod
- [ ] E4 Session recording + artifacts filed to the client folder
