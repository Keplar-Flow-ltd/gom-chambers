# GAIA — Product Video Script
**Title:** "GAIA — Your Property Practice, Running Itself"
**Runtime:** ~3:30 · **Format:** screen-recording + voiceover (one narrator, warm/confident) · **Audience:** Gom Chambers (Principal + PA) — wow-targeted
**Rule for the editor:** every number on screen is real dummy-data arithmetic from the staging build; no mockups needed — record the actual workspace.

---

## SCENE 1 — THE PAIN (0:00–0:25)
**Visual:** slow pans of paper ledger, WhatsApp voice notes piling, a missed renewal calendar.
**VO:** "Rent tracked in notebooks. Renewals remembered by memory. Receipts in three different inboxes. If one date slips, it costs the practice real money — and nobody meant for it to happen."
**Text on screen:** *Oversight is the enemy.*

## SCENE 2 — ENTER GAIA (0:25–0:50)
**Visual:** GAIA Portal fades in. Hold on the four KPI cards, then the arrears chart.
**VO:** "This is GAIA — your entire property practice in one workspace. Expected rent. Money actually received. What's unpaid. Which estate carries the risk. Live, always current, one screen."
**Text:** *₦1,800,000 expected · ₦5,055,000 verified · ₦745,000 arrears* (cards visible)

## SCENE 3 — THE CASCADE (0:50–1:20) ⭐ hero moment
**Visual:** PA view → Pending Verification (P-014, ₦200,000). Check bank app split-screen. Click Status → Verified. Cut: arrears queue number drops 745k→545k; estate chart bar shrinks; donut nudges.
**VO:** "One confirmation — and every dashboard, chart, and ledger tells the truth at the same moment. The tenant's balance updates. The estate's arrears drop. The portfolio recalculates. No spreadsheets. No 'whose number is right?' Just one truth."
**Text:** *745,000 → 545,000. Everywhere. Instantly.*

## SCENE 4 — NEVER MISS A DATE (1:20–1:50)
**Visual:** Calendar view filling with lease ends + rent dates; then the timeline swimlanes by estate.
**VO:** "Every lease end. Every rent date. Every deadline — on a calendar, with the whole portfolio as a timeline. GAIA flags renewals ninety, sixty, thirty days out, automatically. The system remembers so nobody has to."
**Text:** *🚨 30 · ⚠️ 60 · ℹ️ 90 — automatic.*

## SCENE 5 — FIELD TO OFFICE IN TEN SECONDS (1:50–2:20) ⭐
**Visual:** phone in hand at a property. Field Portal → incident form → photo → submit. Cut to PA's triage queue: the task appears.
**VO:** "A burst pipe at Unit A-04. The field agent opens his phone, logs it, snaps a photo. Ten seconds later it's in the PA's triage queue — classified, owned, dated. No WhatsApp. No paper. No 'I thought you saw it.'"
**Text:** *Field → Triage. 10 seconds.*

## SCENE 6 — THE MONEY IS PROTECTED (2:20–2:40)
**Visual:** Backend page (locked icon), then Field portal showing ONLY assignments. Attempt to open payments → no access.
**VO:** "And the money? Field agents never see it — not hidden, simply never shared. Records are verified before they count. Access is granted per role, by the Principal alone. GAIA is built for a legal practice: evidence, audit trail, and boundaries."

## SCENE 7 — GOOGLE, FLEXED (2:40–3:05) ⭐
**Visual:** Google Calendar receiving GAIA deadlines with a reminder popping on a phone; Drive folder GAIA/Estates/…/TEN-003 with lease + receipts, linked from the tenancy row.
**VO:** "It lives where your firm already lives. Deadlines drop onto Google Calendar with real reminders. Leases, receipts, and photos file into Google Drive — one folder per tenancy, linked to its record. Your filing cabinet, self-building."
**Text:** *Calendar ✓ Drive ✓ Gmail (soon) ✓*

## SCENE 8 — ASK GAIA ANYTHING (3:05–3:20)
**Visual:** Notion AI answering "Which estates have arrears and what expires this month?" in plain English.
**VO:** "And you can just ask. In plain English. The workspace answers — and behind it, Keplar's delivery agent keeps the knowledge current."
**Text:** *Ask. It answers.*

## SCENE 9 — CLOSE (3:20–3:35)
**Visual:** Portal one more time, slow zoom on the four cards. Logo.
**VO:** "GAIA. Built for Gom Chambers. Every lease, every naira, every deadline — accounted for. This is your practice, running itself."
**Text:** *GAIA · Gom Chambers × Keplar Flow*

---
### Production notes
- Record staging workspace at 1440p; phone scene on a real phone.
- All figures from the frozen dummy baseline (745k/545k/845k cascade) — verified arithmetic, safe for client eyes (dummy data, contract-clean).
- Music: warm minimal, ducked under VO. No stock-footage offices — the real UI is the star.
- Optional 15s cutdown: Scenes 3 + 5 + 9.
