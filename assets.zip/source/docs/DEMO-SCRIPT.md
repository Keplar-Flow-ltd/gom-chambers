# UAT Demo Script — click-by-click, with expected values

> Drive from the [GAIA root](https://app.notion.com/p/3dfc227e1e0281fb99d0f5430b24b1f0).
> Every expected value below is verified dummy-data arithmetic. If any screen
> deviates, pause and say "let me check that" — never demo a wrong number.

## Stop 1 — 🏡 GAIA Portal (2 min)
- Land. Say nothing for 30 seconds. Let the cover, KPI cards, and charts speak.
- Point at the four cards: **₦1,800,000 expected · ₦5,055,000 verified · ₦745,000 active arrears · 1,045,000 portfolio**.
- Chart: arrears by estate — "Beta and Gamma carry the weight: 450k and 475k against Alpha's 120k."

## Stop 2 — The P-014 cascade (4 min) ⭐ the accountability moment
- Open 📊 GAIA Home → arrears queue. Read the three active rows aloud: TEN-003 450k, TEN-005 175k, TEN-002 120k.
- Open 🧭 PA Portal → **💵 Pending verification** → exactly one row: **P-014, ₦200,000, BT / REF-DUMMY-014**.
- Set Status → **Verified**. Say: "Watch the books."
- Back to arrears queue: TEN-003 now **₦250,000**; queue total now **₦545,000**; portfolio **₦845,000**.
- Line to land: *"One verification, and every dashboard, chart, and ledger in this workspace told the truth simultaneously. That is the oversight problem, solved."*

## Stop 3 — 👑 Principal Portal (3 min)
- Escalation queue → calendar: "September: three lease ends inside 30 days — TEN-006 in 10 days is the phone call you make this week."
- Portfolio timeline: estates as swimlanes, leases as bars. "Your whole portfolio, one screen, forever-current."

## Stop 4 — 📅 Calendar & Accountability Hub (2 min)
- Three calendars: lease ends, task deadlines, **payment due dates**.
- Responsibility boards: Principal / PA / Legal open items. "Nothing is unowned. Every card names its owner and its next action."

## Stop 5 — 🧭 PA Portal (2 min)
- Triage queue, cleaning grid, vacant/maintenance gallery.
- "This is Sendo's morning: verify, dispatch, re-let."

## Stop 6 — ⚖️ Legal Portal (2 min)
- Renewal monitor sorted to expiry; swimlane timeline; case board (TEN-008 dispute visible).

## Stop 7 — 🔧 Field Portal on a PHONE (4 min) ⭐ fastest wow
- Hand velocity: open Field Portal on mobile (or narrow the window).
- Tap the incident form → submit: "Burst pipe, Unit A-04, photo attached" (any placeholder text).
- Switch to PA Portal → triage queue → **the new task is there**, classified Maintenance Request.
- *"Field to triage in ten seconds. No WhatsApp. No lost paper."*

## Stop 8 — 🔒 Security posture (2 min)
- Show 🔒 GAIA Master Backend page; state: only Principal + PA ever get in.
- Show 🛡 Hardening page: MFA plan, access audit, the §13.2 zero-retention exit.

## Stop 9 — 🤝 Notion AI live (3 min)
- Ask Notion AI: *"Which estates have arrears and what's the renewal risk?"*
- Expected: it reads the workspace (and can call the GAIA bridge for the baseline) → Alpha 120k/Beta 450k/Gamma 475k + expiry tiers.
- "Your workspace answers questions in plain English. It also talks to our delivery agent — verified pipeline, defects found and fixed by the two of them."

## Stop 10 — Permission proof (2 min)
- Open a Field-restricted link (e.g., Payments view URL in a logged-out/incognito context or describe guest posture).
- "Access isn't hidden — it's absent. Money databases are never shared to field agents."

## Close (1 min)
- Recap numbers: 6 databases, 53 dummy records, every figure traceable. "The staging you just watched is the production system, minus your real data."

**Demo discipline:** never edit schema live; never show the backend tables unfiltered; if asked "can it do X" — capture it in the session log, classify §3.5 vs §7 after.
