# Live-Data Intake Protocol — Keplar Flow × Gom Chambers PA

**Client-facing document (v1, for the session).** Governs how Gom's PA and Keplar
Flow bring real records into the production workspace safely, per the Agreement
(§3.3 written authorization, §12 NDPA 2023, §12.3 no live data outside the client
workspace).

## 1. The gate before anything

- Live data enters **only after written authorization** from the Principal (email
  suffices, per §3.3) naming: which record types, which period, who provides them.
- Until then: everything stays dummy, tagged `Data Class = DUMMY`.
- Live records are tagged `Data Class = LIVE` on arrival — the swap is a filter,
  never a guess.

## 2. What the PA collects (six schemas, same shapes)

| Database | Minimum fields | Format |
|---|---|---|
| Estates | name, owner/client, location, type | one row per estate |
| Units | code, estate, type, rent, status | one row per unit |
| Tenants | name, phone, email, ID status | contacts as the client holds them |
| Tenancies | tenant, unit, start, end, rent, frequency | **the spine — most important** |
| Payments | tenancy, amount, date, method/reference | receipts stay in Drive |
| Tasks | anything currently tracked on paper/WhatsApp | even partial is fine |

- CSV or typed directly into the intake page — both accepted. Templates provided.
- **Documents (leases, receipts) go to Drive**, in
  `GAIA/Estates/<Estate>/Tenancies/<TEN-xxx>/`; the PA pastes links into rows.

## 3. The weekly rhythm (the working model)

| When | Who | What |
|---|---|---|
| Monday | PA | New records/intakes dropped into the intake page |
| Tue–Thu | Keplar (GAIA agent) | Verify, dedupe, tag LIVE, wire relations, flag anomalies |
| Thursday | PA | Reviews flags in workspace; answers queries on rows |
| Friday | PA + Keplar | Digest: new arrears, upcoming expiries, open tasks → Principal |
| Continuous | PA | Payments verified as bank statements confirm (Pending → Verified) |

## 4. Rules of the road

1. Live data **never leaves the client workspace** — no exports to us, no copies.
2. Anomalies (missing unit, tenant without tenancy, payment without a tenancy)
   become GAIA Tasks assigned to the PA — the system polices its own intake.
3. Corrections happen in the workspace, tracked by edit history — no shadow copies.
4. Anything the PA can't verify stays `Pending Verification` and never counts in totals.
5. The Principal sees arrears/dispute figures only from Verified data.

## 5. What "done" looks like (intake complete)

- Every tenancy has tenant + unit + dates; every payment has a tenancy.
- Drive folder per tenancy linked; receipts attached.
- Baseline switched from dummy numbers to live numbers, re-run QA with the
  Principal's own expectations; Final Acceptance on that basis.
