# Design Team Brief — GAIA Client-Facing Library Facelift

**You are receiving:** every client-facing artifact that is NOT the core Notion
interface. Your mandate: upgrade, brand, and unify this library for delivery to
Gom Chambers. **The core GAIA workspace (databases/views/portals in Notion) is
out of scope** — do not redesign it; match it.

## What's in this package

```
wiki/                     13 self-contained HTML pages (GAIA onboarding wiki)
                          — index + 4 role onboarding + 8 deep dives.
                          Generated from generate_wiki.py (edit content there
                          or in-place; keep pages self-contained + linked).
VIDEO-SCRIPT.md           Full product video script (9 scenes, ~3:30).
demo-day/                 SESSION-PLAN.md · DEMO-SCRIPT.md ·
                          PA-DATA-INTAKE-PROTOCOL.md · PRE-SESSION-CHECKLIST.md
assets/                   The earlier design package's ready assets:
                          5 covers (3000×1200), palette card, 3 chart mockups.
design-package-reference  Path to the full 23-pp research handoff (in repo:
                          operatives/gaia/sources/design-upgrade/…).
STATE-OF-WORK.md          Full project context (rev 3) — read second.
```

## Design direction (locked in the research — follow, don't re-litigate)

- Brand: GAIA Forest `#0F3D2E` + Gold `#D4A24C` on warm neutrals `#FBFAF7`;
  blueprint-navy accents `#0F2A43`. Max 4 semantic colors + 1 accent.
- Typography: Inter (default), JetBrains Mono for IDs/refs, Serif reserved for
  legal-document artifacts only.
- Tone: legal-practice formal, warm, plain English. Never cute. Never cluttered.
- Free-tier + Pro-compatible: no dependencies the client workspace can't carry.

## Your upgrade targets (priority order)

1. **Wiki HTML** — visual facelift within the locked palette: covers per page
   (assets/covers), improved hero/header treatments, print-friendly CSS for the
   PA protocol. Keep every page self-contained (inline CSS) and cross-linked.
2. **Video script** — storyboard frames/title cards to accompany the 9 scenes.
3. **Demo-day pack** — one-page branded agenda PDF, demo one-pager for the
   client's hands, branded checklist.
4. Optional: icon set (monochrome line, charcoal/green) for the 6 databases
   per the research icon system.

## Non-negotiables

- Numbers stay exactly as written (they are verified dummy-baseline arithmetic).
- No client PII, no live data, nothing from the client workspace in any asset.
- The wiki's plain-English voice is the point — design around the words,
  never replace them with jargon.
- Deliverables must remain usable offline/single-file (client may print/host).

— Prepared by GAIA (Keplar Flow), 2026-09-19. Questions route through Adebayo.
