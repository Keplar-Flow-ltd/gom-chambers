# GAIA Client Demo & Handover Session — Plan

**Working title:** "From Blueprint to Reality — GAIA UAT Demo & Production Kickoff"
**Duration:** 90 minutes (+30 min buffer) · Google Meet (recorded, client consent)
**Participants:** Barrister Emmanuel Gom (Principal) · Gom's PA · Adebayo Emmanuel (Keplar Flow, Technical Lead) · GAIA delivery agent (screen-driven by Adebayo) · Notion AI (workspace assistant, demonstrated live)
**Prerequisite:** Pre-session checklist (separate file) complete — esp. the client's **pre-created Pro account** and granted access.

---

## Agenda (90 min)

| # | Min | Segment | Lead | Outcome |
|---|---|---|---|---|
| 1 | 0–5 | Welcome & agenda | Adebayo + Gom | Alignment on the three goals: UAT demo, team intro, prod kickoff |
| 2 | 5–10 | **Our ops team** | Adebayo | Team card below — who does what, single point of contact |
| 3 | 10–35 | **UAT demo** (staging workspace) | Adebayo (driving) + Gaia/Notion AI (live) | Client sees the system working end-to-end on dummy data; UAT checklist A/B/C sections walked live |
| 4 | 35–45 | **Q&A / client test cases** | All | Client-selected scenarios run on demand |
| 5 | 45–60 | **PA working model** (live-data intake) | Adebayo + Gom's PA | Data intake protocol agreed; PA's weekly rhythm understood |
| 6 | 60–80 | **Prod kickoff** (parallel build) | Adebayo + Gom | Access verified on the pre-created Pro workspace; build starts (or scheduled); gates restated (§3.3 live-data authorization, Sch-1 §4 automations) |
| 7 | 80–90 | Wrap: next steps, timeline, written recap | Adebayo | Recap email same day; acceptance path to Final Acceptance |

## 2 · Ops team card (client-facing)

| Member | Role in delivery | In the session |
|---|---|---|
| **Emmanuel Adebayo** — Founder/CTO, Keplar Flow | Technical Lead; single point of contact; all client-facing comms | Drives demo, owns commitments |
| **GAIA delivery agent** (Keplar's delivery automation) | Built the staging + production systems; runs verification, dashboards, docs | Behind the screen: builds live during segment 6 if access is ready |
| **Notion AI** (workspace assistant, client's plan) | Day-to-day helper post-handover: answers, summaries, guided edits | Demonstrated live in segment 3 (queries GAIA's knowledge bridge) |
| **Gom Chambers side**: Principal (acceptance authority), PA (data intake + daily ops), Legal + Field (portals) | — | Introduced to their surfaces during demo |

## 3 · UAT demo flow (the wow-moments, in order)

1. **🏡 GAIA Portal** — first impression: covers, KPI cards, charts (60s of silence, let it land)
2. **The P-014 cascade** — verify a pending payment live; watch ₦745k→₦545k, Beta 450k→250k, portfolio 1,045k→845k ripple (the accountability story)
3. **👑 Principal Portal** — escalation queue + rent & expiry calendar + portfolio timeline ("when is anything due" answered)
4. **📅 Calendar Hub** — lease ends / task deadlines / payment due dates; responsibility boards ("who owns what")
5. **🧭 PA Portal** — pending-verification worklist + triage + cleaning grid (the PA's daily reality)
6. **⚖️ Legal Portal** — renewal monitor + swimlane timeline + case board
7. **🔧 Field Portal (phone!)** — submit a live incident via the form → it appears in PA triage in front of them (the fastest wow)
8. **🔒 Security posture** — backend isolation, role boundaries, the staged MFA/hardening page
9. **🤝 Notion AI live** — PA asks a natural question; AI answers from the workspace + GAIA bridge (cross-agent demo)
10. **Permission proof** — open Field view restricted surface; show "no access" is real

## 4 · PA working model (agreed in segment 5)

→ Full protocol in `PA-DATA-INTAKE-PROTOCOL.md` (client-facing).
Essence: PA collects per the intake templates (same 6 schemas) → drops into
a shared intake page → Keplar verifies + seeds → PA verifies in workspace →
weekly Friday digest rhythm. **No live data before §3.3 written authorization;
live data never leaves the client workspace.**

## 5 · Prod parallel build (segment 6)

- Gom's pre-created Pro account/workspace → invite Adebayo (member, admin rights as needed, **never sole owner** §3.2)
- New OAuth consent for the prod workspace (URL generated live by GAIA — one click by Gom/Adebayo)
- `build_production.py --apply` runs during the session (dummy data), then dual-relation UI pass
- UAT checklist re-run against prod; then the live-data swap ONLY after written §3.3 authorization
- Automations remain disabled until Sch-1 §4 sign-off

## 6 · Risks & fallbacks

| Risk | Fallback |
|---|---|
| Free-plan staging quota hiccups mid-demo | Demo order front-loads wow-moments 1–7 (quota-independent views) |
| Pro workspace not pre-created | Segment 6 becomes a guided set-up appointment; segments 1–5 unchanged |
| Client test case needs structure change | Log it; classify §3.5-necessary vs §7-change on the call, confirm in writing after |
| Live-data questions | Point to the gated path; never improvise authorization on a call |
