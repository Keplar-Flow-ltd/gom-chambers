# -*- coding: utf-8 -*-
"""QA checks for the GAIA asset library: broken local links, emoji presence,
file inventory. Fails loudly so a bad build is caught before delivery."""
import os, re, unicodedata

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ATTR = re.compile(r'(?:src|href)\s*=\s*"([^"]+)"')

def emoji_scan(text):
    hits = []
    for ch in text:
        cp = ord(ch)
        if cp < 0x2000: continue
        if (0x1F000 <= cp <= 0x1FAFF) or (0x2600 <= cp <= 0x27BF) or (0x2B00 <= cp <= 0x2BFF) \
           or cp in (0x2139,) or (0xFE00 <= cp <= 0xFE0F):
            hits.append(ch)
    return hits

broken, emoji_hits, files = [], [], []
for root, _, names in os.walk(KIT):
    if "source" in root.split(os.sep) or "tools" in root.split(os.sep):
        continue
    for nm in names:
        p = os.path.join(root, nm)
        files.append(p)
        rel = os.path.relpath(p, KIT)
        if nm.endswith((".html", ".svg")):
            txt = open(p, encoding="utf-8").read()
            e = emoji_scan(txt)
            if e:
                emoji_hits.append((rel, "".join(sorted(set(e)))))
            if nm.endswith(".html"):
                for a in ATTR.findall(txt):
                    if a.startswith(("http", "#", "mailto:", "data:", "javascript:")): continue
                    tgt = os.path.normpath(os.path.join(root, a.split("#")[0]))
                    if not os.path.exists(tgt):
                        broken.append((rel, a))

ext = {}
for f in files:
    ext[os.path.splitext(f)[1]] = ext.get(os.path.splitext(f)[1], 0) + 1
print("files:", len(files), "| by type:", ext)
print("broken local links:", len(broken))
for r, a in broken: print("   !", r, "->", a)
docs = [(os.path.relpath(p,KIT), os.path.getsize(p)) for p in files if p.endswith(".html")]
docs.sort(key=lambda x:-x[1])
print("html docs:", len(docs), "| largest:", docs[0][0], f"{docs[0][1]//1024}KB")
print("emoji found:", len(emoji_hits))
for r, e in emoji_hits: print("   ~", r, repr(e))
