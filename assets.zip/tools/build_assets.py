# -*- coding: utf-8 -*-
"""Generate GAIA brand assets: logo system, icon set, cover system, chart
plates, and video title cards. All vector, offline, self-contained."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gcommon import P, FONT_SANS, FONT_MONO, FONT_LEGAL, ICONS, icon_sprite, write_text

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = os.path.join(KIT, "assets")

# ================================================================= LOGO
def logo_mark(fg=None, bg=None, g="#D4A24C"):
    """Rounded-square seal with a G monogram. Small-size brand mark."""
    fg = fg or P["forest"]; bg = bg or "none"
    rect = (f'<rect width="96" height="96" rx="22" fill="{bg}"/>' if bg != "none" else "")
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" role="img" '
            f'aria-label="GAIA mark">{rect}'
            f'<path d="M65 35.5a19 19 0 1 0 2.5 26.5H55" fill="none" stroke="{g}" '
            f'stroke-width="8.5" stroke-linecap="round"/>'
            f'<circle cx="48" cy="48" r="3.4" fill="{fg}"/></svg>')

def logo_monogram(color=None):
    color = color or P["forest"]
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" role="img" aria-label="G">'
            f'<path d="M71 31a26 26 0 1 0 3 34H57" fill="none" stroke="{color}" '
            f'stroke-width="10" stroke-linecap="round"/></svg>')

def logo_wordmark(tagline=False):
    t = ""
    if tagline:
        t = (f'<text x="10" y="126" font-family="{FONT_MONO}" font-size="26" '
             f'letter-spacing="7" fill="{P["muted"]}">GOM CHAMBERS · PROPERTY OPERATIONS</text>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 160" role="img" aria-label="GAIA">'
            f'<text x="8" y="100" font-family="{FONT_SANS}" font-size="104" font-weight="800" '
            f'letter-spacing="6" fill="{P["forest"]}">GAIA</text>'
            f'<circle cx="404" cy="86" r="9" fill="{P["gold"]}"/>{t}</svg>')

def logo_lockup(dark=False):
    ink = P["paper"] if dark else P["forest"]
    sub = "#B9CBDD" if dark else P["muted"]
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 720 120" role="img" aria-label="GAIA">'
            f'<path d="M57 21.5a19.5 19.5 0 1 0 2.6 27H46" fill="none" stroke="{P["gold"]}" '
            f'stroke-width="8" stroke-linecap="round"/>'
            f'<text x="104" y="74" font-family="{FONT_SANS}" font-size="66" font-weight="800" '
            f'letter-spacing="4" fill="{ink}">GAIA</text>'
            f'<circle cx="300" cy="62" r="6.5" fill="{P["gold"]}"/>'
            f'<text x="106" y="100" font-family="{FONT_MONO}" font-size="15" letter-spacing="4" '
            f'fill="{sub}">NOTION-NATIVE PROPERTY OPERATIONS</text></svg>')

# ================================================================= COVERS
COVER_THEMES = {
  "navy-blueprint":  dict(bg1="#12324F", bg2="#0A1F33", ink="#FBFAF7", sub="#AFC6DC",
                          accent="#D4A24C", mode="grid", frame="#24486A"),
  "emerald-executive":dict(bg1="#14513A", bg2="#0A2A1F", ink="#FBFAF7", sub="#BFD6C8",
                          accent="#D4A24C", mode="wm"),
  "charcoal-gold":   dict(bg1="#2A2721", bg2="#17150F", ink="#F4F0E6", sub="#B9B29C",
                          accent="#D4A24C", mode="rule"),
  "forest-gold":     dict(bg1="#0F3D2E", bg2="#08migrate", ink="#FBFAF7", sub="#C4D8CD",
                          accent="#D4A24C", mode="seal"),
  "ivory-minimal":   dict(bg1="#FBFAF7", bg2="#F4F0E6", ink="#0F3D2E", sub="#5C5648",
                          accent="#9A742E", mode="minimal"),
}
COVER_THEMES["forest-gold"]["bg2"] = "#08251A"

def cover_svg(theme, title, subtitle, ref, w=3000, h=1200):
    t = COVER_THEMES[theme]
    defs = (f'<defs><linearGradient id="cbg" x1="0" y1="0" x2="1" y2="1">'
            f'<stop offset="0" stop-color="{t["bg1"]}"/><stop offset="1" stop-color="{t["bg2"]}"/></linearGradient>'
            f'<pattern id="grid" width="150" height="150" patternUnits="userSpaceOnUse">'
            f'<path d="M150 0H0V150" fill="none" stroke="{t.get("frame","#fff")}" stroke-width="2" opacity="0.35"/></pattern>'
            f'<pattern id="dots" width="46" height="46" patternUnits="userSpaceOnUse">'
            f'<circle cx="4" cy="4" r="2.4" fill="{t["accent"]}" opacity="0.28"/></pattern></defs>')
    decor = ""
    if t["mode"] == "grid":
        decor = f'<rect width="{w}" height="{h}" fill="url(#grid)"/>'
    elif t["mode"] == "wm":
        decor = (f'<text x="{w-140}" y="{h-120}" text-anchor="end" font-family="{FONT_SANS}" '
                 f'font-size="760" font-weight="800" fill="{t["accent"]}" opacity="0.08">G</text>')
    elif t["mode"] == "seal":
        decor = (f'<circle cx="{w*0.82}" cy="{h*0.68}" r="360" fill="none" stroke="{t["accent"]}" '
                 f'stroke-width="2" opacity="0.22"/><circle cx="{w*0.82}" cy="{h*0.68}" r="250" '
                 f'fill="none" stroke="{t["accent"]}" stroke-width="2" opacity="0.16"/>')
    elif t["mode"] == "minimal":
        decor = (f'<rect x="{w-620}" y="-200" width="1400" height="1800" fill="url(#dots)" opacity="0.5"/>'
                 f'<rect x="60" y="60" width="{w-120}" height="{h-120}" fill="none" '
                 f'stroke="{t["frame"] if "frame" in t else t["accent"]}" stroke-width="2" opacity="0.5"/>')
    elif t["mode"] == "rule":
        decor = (f'<rect x="{w*0.62}" y="0" width="{w*0.38}" height="{h}" fill="{t["accent"]}" opacity="0.06"/>')
    seal = (f'<g transform="translate({w-330} 210)">'
            f'<circle r="108" fill="none" stroke="{t["accent"]}" stroke-width="3" opacity="0.9"/>'
            f'<circle r="88" fill="none" stroke="{t["accent"]}" stroke-width="1.4" opacity="0.45"/>'
            f'<path d="M-30 -18a26 26 0 1 0 3.4 36H-38" fill="none" stroke="{t["accent"]}" '
            f'stroke-width="11" stroke-linecap="round"/></g>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-label="{title}">'
            f'{defs}<rect width="{w}" height="{h}" fill="url(#cbg)"/>{decor}'
            f'<rect x="200" y="300" width="6" height="520" rx="3" fill="{t["accent"]}"/>'
            f'<circle cx="203" cy="300" r="17" fill="{t["accent"]}"/>'
            f'<text x="286" y="560" font-family="{FONT_SANS}" font-size="300" font-weight="800" '
            f'letter-spacing="10" fill="{t["ink"]}">GAIA</text>'
            f'<text x="292" y="672" font-family="{FONT_SANS}" font-size="62" font-weight="600" '
            f'fill="{t["ink"]}" opacity="0.94">{title}</text>'
            f'<text x="292" y="742" font-family="{FONT_SANS}" font-size="38" fill="{t["sub"]}">{subtitle}</text>'
            f'{seal}'
            f'<text x="292" y="1040" font-family="{FONT_MONO}" font-size="30" letter-spacing="6" '
            f'fill="{t["sub"]}">{ref}</text></svg>')

PAGE_COVERS = [  # theme, page, title, subtitle  (wiki hero assignment)
  ("index",               "emerald-executive","GAIA Onboarding Wiki","Your guide to working with GAIA"),
  ("onboarding-principal","forest-gold",      "Onboarding — The Principal","Day-one guide in plain English"),
  ("onboarding-pa",       "forest-gold",      "Onboarding — The Personal Assistant","Day-one guide in plain English"),
  ("onboarding-legal",    "navy-blueprint",   "Onboarding — The Legal Associate","Day-one guide in plain English"),
  ("onboarding-field",    "charcoal-gold",    "Onboarding — The Field Agent","Day-one guide in plain English"),
  ("deep-dive-dashboards","navy-blueprint",   "Dashboards, calendars & timelines","Deep dive — GAIA wiki"),
  ("deep-dive-payments",  "emerald-executive","Payments, arrears & verification","Deep dive — GAIA wiki"),
  ("deep-dive-tasks",     "forest-gold",      "Tasks, triage & routing","Deep dive — GAIA wiki"),
  ("deep-dive-tenancies", "forest-gold",      "Tenancies — the spine","Deep dive — GAIA wiki"),
  ("deep-dive-permissions","charcoal-gold",   "Who can see what","Deep dive — GAIA wiki"),
  ("deep-dive-google",    "navy-blueprint",   "Working with Google","Deep dive — GAIA wiki"),
  ("deep-dive-notion-ai", "emerald-executive","Asking GAIA's AI","Deep dive — GAIA wiki"),
  ("deep-dive-recordcare","ivory-minimal",    "Dummy, live & record safety","Deep dive — GAIA wiki"),
]

def hero_svg(theme, kicker, title, h=300):
    t = COVER_THEMES[theme]
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 {h}" preserveAspectRatio="xMidYMid slice" role="img">'
            f'<defs><linearGradient id="h" x1="0" y1="0" x2="1" y2="1">'
            f'<stop offset="0" stop-color="{t["bg1"]}"/><stop offset="1" stop-color="{t["bg2"]}"/></linearGradient></defs>'
            f'<rect width="1200" height="{h}" fill="url(#h)"/>'
            f'<text x="1020" y="{h+40}" text-anchor="end" font-family="{FONT_SANS}" font-size="300" '
            f'font-weight="800" fill="{t["accent"]}" opacity="0.10">G</text>'
            f'<circle cx="1082" cy="72" r="34" fill="none" stroke="{t["accent"]}" stroke-width="2.2" opacity="0.85"/>'
            f'<path d="M1072 66a10 10 0 1 0 1.3 13.6H1069" fill="none" stroke="{t["accent"]}" stroke-width="4.4" stroke-linecap="round"/>'
            f'<rect x="72" y="{h*0.30}" width="4" height="{h*0.42}" rx="2" fill="{t["accent"]}"/>'
            f'<text x="104" y="{h*0.5}" font-family="{FONT_MONO}" font-size="20" letter-spacing="4" '
            f'fill="{t["accent"]}">{kicker.upper()}</text>'
            f'<text x="102" y="{h*0.74}" font-family="{FONT_SANS}" font-size="52" font-weight="700" '
            f'letter-spacing="-1" fill="{t["ink"]}">{title}</text></svg>')

# ================================================================= CHARTS
INK, MUT, LINE, GOLD, FOREST = P["ink"], P["muted"], P["line"], P["gold"], P["forest"]
GOLD7, GOLD05 = P["gold7"], P["gold05"]

def chart_arrears(w=1000, h=560):
    rows = [("Alpha", 120000), ("Beta", 450000), ("Gamma", 475000)]
    top, rowh, lx, maxv, bw = 132, 100, 210, 500000, 590
    out = [f'<text x="40" y="56" font-family="{FONT_MONO}" font-size="15" letter-spacing="3" fill="{MUT}">ARREARS BY ESTATE</text>',
           f'<text x="40" y="92" font-family="{FONT_SANS}" font-size="26" font-weight="700" fill="{INK}">Which estate carries the risk</text>']
    base_y = top + 3*rowh - 34
    out.append(f'<line x1="200" y1="{base_y}" x2="{lx+bw+40}" y2="{base_y}" stroke="{P["line2"]}" stroke-width="1.6"/>')
    for i, (name, v) in enumerate(rows):
        y = top + i*rowh
        wd = bw * v / maxv
        hi = name == "Gamma"
        out.append(f'<text x="{lx-18}" y="{y+34}" text-anchor="end" font-family="{FONT_SANS}" font-size="20" fill="{INK}">{name}</text>')
        out.append(f'<rect x="{lx}" y="{y+6}" width="{wd:.0f}" height="42" rx="7" fill="{FOREST if not hi else P["forest2"]}"/>')
        out.append(f'<circle cx="{lx+wd+22:.0f}" cy="{y+27}" r="4" fill="{P["gold"]}"/>')
        out.append(f'<text x="{lx+wd+36:.0f}" y="{y+34}" font-family="{FONT_MONO}" font-size="19" fill="{P["gold7"]}">&#8358;{v:,}</text>')
    out.append(f'<text x="40" y="{base_y+40}" font-family="{FONT_MONO}" font-size="15" fill="{MUT}">BAR SCALE 0 &#8211; &#8358;500,000</text>')
    out.append(f'<text x="40" y="{base_y+68}" font-family="{FONT_MONO}" font-size="16" fill="{MUT}">TOTAL &#8358;1,045,000 &#183; active &#8358;745,000 + disputed &#8358;300,000 (TEN-008)</text>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-label="Arrears by estate">'
            + "".join(out) + "</svg>")

def donut(cx, cy, r, sw, pct, track, fill):
    import math
    c = 2*math.pi*r
    return (f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{track}" stroke-width="{sw}"/>'
            f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{fill}" stroke-width="{sw}" '
            f'stroke-linecap="round" stroke-dasharray="{c*pct:.1f} {c:.1f}" '
            f'transform="rotate(-90 {cx} {cy})"/>')

def chart_collections(w=1000, h=560):
    import math
    cx, cy, r = 300, 300, 150
    pct = 5055000/5800000  # 87.2%
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-label="Collections progress">'
            f'<text x="40" y="56" font-family="{FONT_MONO}" font-size="15" letter-spacing="3" fill="{MUT}">COLLECTIONS PROGRESS</text>'
            f'<text x="40" y="92" font-family="{FONT_SANS}" font-size="26" font-weight="700" fill="{INK}">Verified money vs. total due</text>'
            f'{donut(cx,cy,r,30,pct,P["forest05"],FOREST)}'
            f'<text x="{cx}" y="{cy-8}" text-anchor="middle" font-family="{FONT_SANS}" font-size="52" font-weight="800" fill="{FOREST}">87%</text>'
            f'<text x="{cx}" y="{cy+26}" text-anchor="middle" font-family="{FONT_MONO}" font-size="15" fill="{MUT}">verified</text>'
            f'<g font-family="{FONT_SANS}" font-size="19" fill="{INK}">'
            f'<rect x="540" y="230" width="16" height="16" rx="4" fill="{FOREST}"/>'
            f'<text x="572" y="244">Verified  &#8358;5,055,000</text>'
            f'<rect x="540" y="286" width="16" height="16" rx="4" fill="{P["forest05"]}"/>'
            f'<text x="572" y="300">Outstanding  &#8358;745,000</text>'
            f'<text x="540" y="372" font-family="{FONT_MONO}" font-size="17" fill="{GOLD7}">DUE &#8358;5,800,000</text></g></svg>')

def chart_occupancy(w=1000, h=560):
    cx, cy, r = 300, 300, 150
    pct = 0.6
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-label="Occupancy">'
            f'<text x="40" y="56" font-family="{FONT_MONO}" font-size="15" letter-spacing="3" fill="{MUT}">OCCUPANCY</text>'
            f'<text x="40" y="92" font-family="{FONT_SANS}" font-size="26" font-weight="700" fill="{INK}">Let units across the portfolio</text>'
            f'{donut(cx,cy,r,34,pct,P["gold05"],GOLD)}'
            f'<text x="{cx}" y="{cy-6}" text-anchor="middle" font-family="{FONT_SANS}" font-size="56" font-weight="800" fill="{FOREST}">60%</text>'
            f'<text x="{cx}" y="{cy+28}" text-anchor="middle" font-family="{FONT_MONO}" font-size="15" fill="{MUT}">6 of 10 units</text>'
            f'<g font-family="{FONT_SANS}" font-size="19" fill="{INK}">'
            f'<rect x="540" y="230" width="16" height="16" rx="4" fill="{GOLD}"/>'
            f'<text x="572" y="244">Let  6 units</text>'
            f'<rect x="540" y="286" width="16" height="16" rx="4" fill="{P["gold05"]}"/>'
            f'<text x="572" y="300">Vacant / maintenance  4 units</text></g></svg>')

# ================================================================= CARDS
CARDS = [
 ("01","THE PAIN","Oversight is the enemy.","Rent tracked in notebooks. Renewals remembered by memory. Receipts in three inboxes.","pain"),
 ("02","ENTER GAIA","One workspace, one truth.","\u20a61,800,000 expected \u00b7 \u20a65,055,000 verified \u00b7 \u20a6745,000 arrears","enter"),
 ("03","THE CASCADE","745,000 \u2192 545,000. Everywhere. Instantly.","One confirmation \u2014 every dashboard, chart and ledger tells the truth at the same moment.","cascade"),
 ("04","NEVER MISS A DATE","\u226430 \u00b7 \u226460 \u00b7 \u226490 \u2014 automatic.","Lease ends, rent dates and deadlines on one calendar; the portfolio as a timeline.","calendar"),
 ("05","FIELD TO OFFICE","Field \u2192 Triage. 10 seconds.","A burst pipe logged from a phone lands classified and owned in the PA's queue.","field"),
 ("06","THE MONEY IS PROTECTED","Evidence, audit trail, boundaries.","Field agents never see payments \u2014 not hidden, simply never shared.","shield"),
 ("07","GOOGLE, FLEXED","Calendar \u00b7 Drive \u00b7 Gmail (soon)","Deadlines onto Google Calendar; leases and receipts into one Drive folder per tenancy.","google"),
 ("08","ASK GAIA ANYTHING","Ask. It answers.","Plain-English questions, answered from the workspace \u2014 and Keplar's agent behind it.","ai"),
 ("09","CLOSE","This is your practice, running itself.","GAIA \u00b7 Gom Chambers \u00d7 Keplar Flow","close"),
]

def card_svg(no, kicker, headline, vo, motif, w=1920, h=1080):
    defs = (f'<defs><linearGradient id="cg" x1="0" y1="0" x2="1" y2="1">'
            f'<stop offset="0" stop-color="#0F3D2E"/><stop offset="1" stop-color="#0A2A1F"/></linearGradient></defs>')
    fig = ""
    if motif == "cascade":
        fig = (f'<g><rect x="1180" y="300" width="520" height="86" rx="14" fill="#D4A24C" opacity="0.18"/>'
               f'<text x="1220" y="358" font-family="{FONT_MONO}" font-size="42" fill="#FBFAF7">\u20a6745,000</text>'
               f'<path d="M1440 420l0 60" stroke="#D4A24C" stroke-width="4"/><path d="M1420 462l20 22 20-22" fill="none" stroke="#D4A24C" stroke-width="4"/>'
               f'<rect x="1180" y="510" width="430" height="86" rx="14" fill="#D4A24C"/>'
               f'<text x="1220" y="568" font-family="{FONT_MONO}" font-size="42" fill="#0A2A1F">\u20a6545,000</text></g>')
    elif motif == "pain":
        fig = "".join(f'<rect x="{1180+i*30}" y="{300+i*40}" width="470" height="14" rx="7" fill="#FBFAF7" opacity="{0.14+0.06*i}"/>' for i in range(5))
    elif motif == "shield":
        fig = (f'<path d="M1450 300l170 74v128c0 108-72 182-170 222-98-40-170-114-170-222V374z" '
               f'fill="none" stroke="#D4A24C" stroke-width="6"/>'
               f'<circle cx="1450" cy="470" r="30" fill="none" stroke="#D4A24C" stroke-width="6"/>'
               f'<path d="M1450 500v70" stroke="#D4A24C" stroke-width="6"/>')
    elif motif == "calendar":
        fig = (f'<rect x="1260" y="300" width="420" height="330" rx="18" fill="none" stroke="#D4A24C" stroke-width="5"/>'
               f'<path d="M1260 380h420M1340 258v70M1600 258v70" stroke="#D4A24C" stroke-width="5"/>'
               + "".join(f'<circle cx="{1330+i*70}" cy="{440+ (j%3)*70}" r="11" fill="#D4A24C" opacity="{0.4 if (i+j)%3 else 1}"/>' for i in range(5) for j in range(3)))
    elif motif == "ai":
        fig = (f'<path d="M1470 300l36 104 104 36-104 36-36 104-36-104-104-36 104-36z" fill="none" stroke="#D4A24C" stroke-width="6"/>')
    elif motif == "google":
        fig = (f'<rect x="1260" y="320" width="200" height="220" rx="16" fill="none" stroke="#D4A24C" stroke-width="5"/>'
               f'<path d="M1520 430h180v180H1520z" fill="none" stroke="#D4A24C" stroke-width="5"/>')
    elif motif == "field":
        fig = f'<rect x="1420" y="250" width="220" height="420" rx="30" fill="none" stroke="#D4A24C" stroke-width="6"/><rect x="1448" y="320" width="164" height="180" rx="10" fill="#D4A24C" opacity="0.25"/>'
    elif motif == "enter":
        fig = "".join(f'<rect x="{1250+i*150}" y="300" width="120" height="120" rx="16" fill="#D4A24C" opacity="{0.9-0.15*i}"/>' for i in range(3))
    elif motif == "close":
        fig = (f'<circle cx="1470" cy="450" r="150" fill="none" stroke="#D4A24C" stroke-width="4" opacity="0.6"/>'
               f'<circle cx="1470" cy="450" r="108" fill="none" stroke="#D4A24C" stroke-width="4" opacity="0.4"/>'
               f'<path d="M1418 420a60 60 0 1 0 7.5 76H1400" fill="none" stroke="#D4A24C" stroke-width="22" stroke-linecap="round"/>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-label="{kicker}">'
            f'{defs}<rect width="{w}" height="{h}" fill="url(#cg)"/>'
            f'<text x="100" y="250" font-family="{FONT_MONO}" font-size="34" letter-spacing="14" fill="#D4A24C">SCENE {no}</text>'
            f'<text x="100" y="430" font-family="{FONT_SANS}" font-size="104" font-weight="800" letter-spacing="-2" fill="#FBFAF7">{kicker}</text>'
            f'<rect x="100" y="480" width="120" height="6" rx="3" fill="#D4A24C"/>'
            f'<text x="100" y="590" font-family="{FONT_SANS}" font-size="44" fill="#E4BE7A">{headline}</text>'
            f'<foreignObject x="100" y="650" width="820" height="300"><div xmlns="http://www.w3.org/1999/xhtml" '
            f'style="font-family:{FONT_SANS};font-size:30px;line-height:1.5;color:#BFD6C8">{vo}</div></foreignObject>'
            f'{fig}'
            f'<text x="100" y="1010" font-family="{FONT_MONO}" font-size="24" letter-spacing="6" fill="#8FA99B">GAIA \u00b7 GOM CHAMBERS \u00d7 KEPLAR FLOW</text></svg>')

# ================================================================= RUN
def run():
    files = []
    # logo
    files += [
      ("logo/gaia-mark.svg", logo_mark(bg=P["forest"])),
      ("logo/gaia-mark-flat.svg", logo_mark()),
      ("logo/gaia-mark-reverse.svg", logo_mark(fg=P["forest"], bg=P["gold"])),
      ("logo/gaia-monogram.svg", logo_monogram()),
      ("logo/gaia-monogram-forest.svg", logo_monogram(P["forest"])),
      ("logo/gaia-wordmark.svg", logo_wordmark()),
      ("logo/gaia-wordmark-tagline.svg", logo_wordmark(True)),
      ("logo/gaia-lockup-horizontal.svg", logo_lockup(False)),
      ("logo/gaia-lockup-reverse.svg", logo_lockup(True)),
      ("icons/gaia-icons.svg", icon_sprite()),
    ]
    # icons, individual files
    for name, inner in ICONS.items():
        files.append((f"icons/gaia-{name}.svg",
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" '
            f'fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" '
            f'stroke-linejoin="round">{inner}</svg>'))
    # covers (standalone, print-ready)
    for th in COVER_THEMES:
        files.append((f"covers/gaia-cover-{th}.svg",
            cover_svg(th, "Client Library", "Gom Chambers \u00b7 Property Operations", "GAIA \u00b7 CL-2026")))
    # charts
    files += [("charts/gaia-chart-arrears-by-estate.svg", chart_arrears()),
              ("charts/gaia-chart-collections.svg", chart_collections()),
              ("charts/gaia-chart-occupancy.svg", chart_occupancy())]
    # cards
    for c in CARDS:
        files.append((f"cards/gaia-card-{c[0]}.svg", card_svg(*c)))
    for rel, content in files:
        write_text(os.path.join(A, rel), content)
    print(f"[assets] wrote {len(files)} files")
    return len(files)

if __name__ == "__main__":
    run()
