# -*- coding: utf-8 -*-
"""Generate GAIA client-facing pages: upgraded onboarding wiki (13 pages),
branded demo-day pack (3 docs), the 9-scene storyboard, and the asset-library
showcase. Content is preserved from the source library; only the visual
system is upgraded (locked palette, SVG icon set, cover system, print CSS)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gcommon import CSS, P, icon, esc, write_text, FONT_MONO, FONT_SANS, FONT_LEGAL
from build_assets import hero_svg, cover_svg, PAGE_COVERS, COVER_THEMES, CARDS

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
W = os.path.join(KIT, "wiki")
D = os.path.join(KIT, "demo-day")
S = os.path.join(KIT, "storyboard")

HERO = {p: (th, t, s) for p, th, t, s in PAGE_COVERS}
FOOT = ("GAIA &#183; Gom Chambers property operations &#183; Wiki v2 (branded) &#183; "
        "Keplar Flow Limited &#183; Every number in examples is dummy data.")

def shell(title, sub, iconname, body, page_key=None, back="index.html", backname="Wiki home",
          kicker="GAIA Wiki"):
    theme = HERO.get(page_key, ("emerald-executive", title, sub))
    hero = hero_svg(theme[0], kicker, theme[1] if page_key else title)
    nav = f'<nav class="bread">&#8592; <a href="{back}">{backname}</a></nav>' if back else ''
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{esc(title)} — GAIA Wiki</title>
<meta name="author" content="Keplar Flow Limited">
<meta name="theme-color" content="{P['forest']}">
<style>{CSS}</style></head>
<body><div class="wrap">
<header class="site"><div class="brandbar">
  <svg class="brandmark" viewBox="0 0 96 96" aria-hidden="true"><rect width="96" height="96" rx="22" fill="{P['forest']}"/><path d="M65 35.5a19 19 0 1 0 2.5 26.5H55" fill="none" stroke="{P['gold']}" stroke-width="8.5" stroke-linecap="round"/></svg>
  <div><h1>{esc(title)}</h1><div class="sub">{sub}</div></div>
</div></header>
<div class="hero">{hero}</div>
{nav}
{body}
<footer><span>{FOOT}</span><span class="mono noprint">wiki v2 &#183; self-contained</span></footer>
</div></body></html>"""

def pill(kind, label, ic):
    return f'<span class="pill p-{kind}">{icon(ic,12)} {label}</span>'

# ------------------------------------------------------------ page builders
def role_page(fname, ic, name, promise, day1, daily, weekly, dives, tips):
    body  = f'<div class="callout c-gold">{icon(ic,18)} <b>{promise}</b></div>'
    body += f'<h2>{icon("check")}Your first 5 minutes</h2><ol class="steps">' + "".join(f"<li>{s}</li>" for s in day1) + "</ol>"
    body += f'<h2>{icon("clock")}A normal day for you</h2><ol class="steps">' + "".join(f"<li>{s}</li>" for s in daily) + "</ol>"
    if weekly:
        body += f'<h2>{icon("calendar")}Your weekly rhythm</h2><div class="card">' + "<br>".join(weekly) + "</div>"
    body += f'<h2>{icon("arrow")}Want to go deeper?</h2><div class="links">' + "".join(f'<a href="{d[0]}">{icon(d[2])}<b>{d[1]}</b></a>' if len(d) > 2 else f'<a href="{d[0]}">{d[1]}</a>' for d in dives) + "</div>"
    if tips:
        body += f'<h2>{icon("seal")}Little things that help</h2><div class="card">' + "<br>".join(tips) + "</div>"
    return shell(f"{name}", "Day-one guide in plain English", ic, body, page_key=fname)

def dive_page(fname, ic, title, one, sections, ideas):
    body = f'<div class="callout c-info">{icon(ic,18)} <b>{one}</b></div>'
    for h, txt in sections:
        body += f"<h2>{icon(ic)}{h}</h2><div class='card'>{txt}</div>"
    body += f'<h2>{icon("ai")}Ideas to make the most of it</h2><ol class="steps">' + "".join(f"<li>{i}</li>" for i in ideas) + "</ol>"
    return shell(title, "Deep dive — GAIA wiki", ic, body, page_key=fname)

def text_page(fname, title, sub, ic, body, kicker="GAIA Wiki", back="index.html", backname="Wiki home"):
    return shell(title, sub, ic, body, page_key=fname, kicker=kicker, back=back, backname=backname)

# ------------------------------------------------------------ index
index_body = f"""
<div class="callout c-gold">{icon("role-principal",18)} <b>Hello!</b> GAIA is your property office in one place.
Pick your role below — a 5-minute guide shows you exactly what to do on day one,
and every guide links to short deep dives when you want to go further.</div>
<h2>{icon("tenants")}Choose your role</h2>
<div class="links">
<a href="onboarding-principal.html">{icon("role-principal")}<b>The Principal</b> — you own the practice. See the big picture, make the decisions that need you.</a>
<a href="onboarding-pa.html">{icon("role-pa")}<b>The Personal Assistant</b> — you keep everything moving. Verify money, route tasks, keep data clean.</a>
<a href="onboarding-legal.html">{icon("role-legal")}<b>The Legal Associate</b> — renewals, notices, disputes. Your desk, your cases.</a>
<a href="onboarding-field.html">{icon("role-field")}<b>The Field Agent</b> — inspections and fixes. Your phone is your office.</a>
</div>
<h2>{icon("chart")}Or explore by topic</h2>
<div class="links">
<a href="deep-dive-dashboards.html">{icon("chart")}Dashboards, calendars &amp; timelines</a>
<a href="deep-dive-payments.html">{icon("payments")}Payments, arrears &amp; verification</a>
<a href="deep-dive-tasks.html">{icon("tasks")}Tasks, triage &amp; routing</a>
<a href="deep-dive-tenancies.html">{icon("tenancies")}Tenancies — the spine</a>
<a href="deep-dive-permissions.html">{icon("shield")}Who can see what</a>
<a href="deep-dive-google.html">{icon("link")}Working with Google (Calendar &amp; Drive)</a>
<a href="deep-dive-notion-ai.html">{icon("ai")}Asking GAIA's AI</a>
<a href="deep-dive-data-care.html">{icon("seal")}Dummy data, live data &amp; keeping records safe</a>
</div>"""

# ------------------------------------------------------------ content
ROLES = [
 ("onboarding-principal.html","role-principal","Onboarding — The Principal",
  "GAIA shows you what needs <b>your</b> decision — and quietly handles the rest. You will never dig for a number again.",
  ["Open <b>GAIA Portal</b>. The four cards at the top tell you the money story: expected rent, what's been received, what's unpaid, and the whole portfolio position.",
   "Look at the three queues below: <b>arrears</b> (red), <b>overdue tasks</b> (orange), <b>expiring leases</b> (blue). Red first. That's your to-do list.",
   "Click the <b>calendar</b> — every rent date and lease end for the month is already there.",
   "Open the <b>timeline</b> — your whole portfolio as bars on a timeline, grouped by estate.",
   "That's it. Everything else waits for your PA's Friday summary."],
  ["Glance at the Portal cards (2 minutes).",
   "Anything in a red banner needs a decision — approve, instruct, or ask the PA to draft it.",
   "Check the escalation queue: items <i>Awaiting Principal Validation</i> are waiting for your sign-off."],
  ["<b>Friday:</b> your PA sends a one-page digest — new arrears, expiries, open tasks. If the numbers match the Portal (they will), you're covered."],
  [("deep-dive-dashboards.html","Dashboards, calendars &amp; timelines — what every screen is telling you","chart"),
   ("deep-dive-payments.html","Understand the money: verification, arrears, and why totals only count confirmed money","payments"),
   ("deep-dive-permissions.html","Who can see what — and why you are the only one who holds the keys","shield")],
  ["Numbers on every screen come only from <b>verified</b> records — if a payment isn't confirmed, it isn't counted.",
   "You are the workspace owner: only you (or people you name) can invite or remove anyone. That's by design.",
   "Ask the AI anything — plain English works: \u201cWhich estates have arrears?\u201d"]),
 ("onboarding-pa.html","role-pa","Onboarding — The Personal Assistant",
  "You are the operational heart. GAIA turns scattered messages into clean records — you verify, route, and keep the machine honest.",
  ["Open <b>PA Portal</b>. Bookmark it — this is your home screen.",
   "Find <b>Pending verification</b>. Anything here is money waiting for you to check against the bank statement. Check it, then set Status &#8594; <b>Verified</b>. Watch the whole workspace update.",
   "Check the <b>Triage queue</b> — new issues from the field land here for you to route.",
   "Glance at <b>Vacant / maintenance</b> — your re-letting pipeline."],
  ["Morning: clear pending verifications (each one takes under a minute).",
   "Route triage items: maintenance &#8594; field, notices &#8594; legal, anything big &#8594; mark <i>Awaiting Principal Validation</i> for the boss.",
   "Update the <b>Next Action</b> line on every task you touch — one sentence is enough. This is how accountability works here.",
   "Add new records as they arrive (new tenant, new payment) — tagging them like the examples."],
  ["<b>Monday:</b> collect new intake records.<br><b>Thursday:</b> review flags GAIA raised on data.<br><b>Friday:</b> send the digest (GAIA's views give you every number)."],
  [("deep-dive-payments.html","The full verification story + the famous cascade example","payments"),
   ("deep-dive-tasks.html","Triage, routing and task classes — running the day","tasks"),
   ("deep-dive-data-care.html","Keeping data clean: dummy vs live, and the intake rules","seal"),
   ("deep-dive-dashboards.html","Every view on your portal explained","chart")],
  ["Never leave a task without an owner or a Next Action — the boards police this.",
   "If something looks wrong in a number, check verification status first — that's the answer 9 times out of 10.",
   "Field agents' reports arrive as tasks automatically — no retyping."]),
 ("onboarding-legal.html","role-legal","Onboarding — The Legal Associate",
  "Renewals, notices, and disputes — your matters are already sorted, timed, and waiting.",
  ["Open <b>Legal Portal</b>.",
   "The <b>Renewal monitor</b> sorts every lease by how soon it ends — top of the list needs you first.",
   "Open the <b>lease timeline</b>: estates as swimlanes, leases as bars. See conflicts and clusters instantly.",
   "Check the <b>case board</b> — disputes and notice work, by stage."],
  ["Work the renewal monitor top-down: critical (\u226430 days) first.",
   "Draft notices from your templates; log each step on the matter's task so history is automatic.",
   "For disputes (like a tenant in arrears under dispute), the balance is held separately — it never quietly disappears."],
  ["<b>Weekly:</b> scan the 90-day window for leases about to enter notice territory and open tasks now."],
  [("deep-dive-tenancies.html","Notice tiers 30/60/90 explained + how tenancy records work","tenancies"),
   ("deep-dive-tasks.html","Using the case board and task classes","tasks"),
   ("deep-dive-permissions.html","Your access level: edit matters, read money — never guess who sees what","shield")],
  [f"The {pill('bad','critical','notice')}{pill('warn','soon','notice')}{pill('info','horizon','notice')}{pill('ok','secure','check')} badges on leases are automatic — they re-compute every day.",
   "Everything you write in a task is timestamped — your file history builds itself."]),
 ("onboarding-field.html","role-field","Onboarding — The Field Agent",
  "Your phone is your office. See your jobs, report in seconds, done.",
  ["Open <b>Field Portal</b> on your phone. Ask the office to share it with you the first time — that's the only page you need.",
   "See <b>My assignments</b> — your inspections and repairs, nearest deadline first.",
   "To report a problem, tap the <b>Log an incident</b> form: what, where, plus a photo. Submit. That's it — the office sees it instantly."],
  ["Open your assignments when you start the day.",
   "At each site: complete the task, or log an incident if you found something new.",
   "Photos matter — one photo per report saves ten messages."],
  ["Nothing weekly — your list is always current."],
  [("deep-dive-tasks.html","How tasks move after you report them (triage explained)","tasks"),
   ("deep-dive-permissions.html","Why you only see your jobs — and why the money pages are never on your phone","shield")],
  ["No app to install — it's a web page that works like one.",
   "If a job needs the office's decision, say so in the report — it'll be routed."]),
]

DIVES = [
 ("deep-dive-dashboards.html","chart","Dashboards, calendars &amp; timelines",
  "Every screen answers one question: what needs attention, when, and who owns it.",
  [("The Portal (big picture)","Four money cards + charts. The cards update the moment a payment is verified. The arrears chart shows which estate carries the risk."),
   ("Queues","Red = arrears, orange = overdue work, blue = expiring leases. Work top-down, red first."),
   ("Calendars","Three: lease ends, task deadlines, payment due dates. Drag nothing — they fill themselves from records."),
   ("Timelines","Leases as bars, estates as swimlanes. Spot a cluster of endings in one glance — that's your renewal season."),
   ("Charts","Arrears by estate (who owes what), collections progress (how much of expected rent is in), task load (who's carrying the work).")],
  ["Start every morning on the calendar view — 60 seconds and you know the day.",
   "Use the timeline in renewal meetings — nobody argues with a picture.",
   "Watch the collections donut after each verification — it's instant feedback that money is real."]),
 ("deep-dive-payments.html","payments","Payments, arrears &amp; verification",
  "One rule keeps every number honest: only <b>verified</b> money counts.",
  [("Life of a payment","Recorded &#8594; <i>Pending Verification</i> &#8594; the PA checks the bank &#8594; <i>Verified</i>. Only then do balances, charts and dashboards count it."),
   ("What a tenant owes","Each tenancy shows: due this period, verified received, and the unpaid balance. A little progress bar fills as money is confirmed — &#9608;&#9608;&#9608;&#9617;&#9617;&#9617;."),
   ("The famous cascade","Verify one &#8358;200,000 payment and watch: the tenant's balance drops, the estate's arrears drop, the portfolio chart drops. Every screen, same second."),
   ("Disputed money","A disputed balance is shown separately and never silently mixed into totals. When it resolves, it resolves visibly.")],
  ["Make verification a fixed daily ritual — it's the heartbeat of trust in every number.",
   "Use the pending-verification view as your bank-reconciliation list.",
   "In owner meetings, show the per-tenant progress bars — landlords understand them instantly."]),
 ("deep-dive-tasks.html","tasks","Tasks, triage &amp; routing",
  "Every piece of work lives in one pipeline: captured &#8594; triaged &#8594; owned &#8594; done.",
  [("Where tasks come from","Field incident form, the PA, the Principal, or intake checks — all land in the same place with an owner and a deadline."),
   ("Classes","Maintenance &#183; Service of Notice &#183; Evidence Processing &#183; Admin Audit. Each portal filters the classes it cares about."),
   ("Routing","PA triages: maintenance &#8594; field agent; notices &#8594; legal; big calls &#8594; Awaiting Principal Validation. Nobody hunts through inboxes."),
   ("Accountability","Every task shows owner, status, due date and a one-line Next Action. The boards make silence visible.")],
  ["End every day with no task lacking a Next Action — it takes two minutes.",
   "Use 'Awaiting Principal Validation' deliberately — it's the boss's shortlist.",
   "Field agents: photo-on-report always. Evidence now, memory never."]),
 ("deep-dive-tenancies.html","tenancies","Tenancies — the spine",
  "Every lease is one record connecting the tenant, the unit, the money, and the dates.",
  [("The spine","Estates contain units; units have tenancies; tenancies carry tenants and payments. Follow any thread from any end."),
   ("Notice tiers — automatic", f"{pill('bad','\u226430 days — act now','notice')} {pill('warn','\u226460 — open renewal talk','notice')} {pill('info','\u226490 — calendar it','notice')} {pill('ok','secure','check')} Recomputed daily, shown everywhere."),
   ("Days to expiry","A live countdown on every lease. The renewal monitor and legal portal sort by it."),
   ("End of life","When a lease ends, it isn't deleted — it's archived. History stays; dashboards move on.")],
  ["Check the critical list every Monday — renewals you start early are renewals you win.",
   "Open the tenancy page before any tenant call — the whole story is one click.",
   "Link every document (Drive) to its tenancy row so files are never hunted."]),
 ("deep-dive-permissions.html","shield","Who can see what",
  "Access isn't hidden — it's <b>absent</b>. You see your work; the money sees only the people it should.",
  [("The roles","Principal &amp; PA — the full system. Legal — matters and case work, money read-only. Field — their assignments and the incident form, nothing else."),
   ("Why it's safe","Field agents never receive the payments or tenancies pages at all — not hidden, not shared. Guests see one page each."),
   ("Who controls it","Only the workspace owner (the Principal) invites or removes anyone. Sharing a page is a deliberate act."),
   ("Audits","The hardening checklist runs before launch and after any staff change: every role tested, every share verified.")],
  ["New staff? Share only their portal — never a database.",
   "Leavers? Remove them the same day; the system makes it one click.",
   "Curious who sees a page? Its Share menu is the single source of truth."]),
 ("deep-dive-google.html","link","Working with Google",
  "GAIA meets your firm where it already works: Google Calendar and Google Drive.",
  [("Calendar","Lease ends, rent dates and deadlines can appear on Google Calendar — with real reminders (a thing Notion views can't do). Options: a read-only shared 'GAIA deadlines' calendar embedded in the workspace (free), or full two-way sync (paid plan)."),
   ("Drive — the filing cabinet","Documents live in Drive, in one tidy structure: GAIA / Estates / [Estate] / Tenancies / [TEN-xxx] / — lease, receipts, letters. Each record links to its folder. Notion stays fast; Drive keeps its sharing and audit."),
   ("Gmail (coming)","Notice letters drafted in GAIA, sent from the firm's Gmail — planned and gated by your approval, like every automation.")],
  ["Paste a Drive link into every new tenancy row — ten seconds today, hours saved in a dispute.",
   "Put the deadlines calendar on the PA's phone: reminders for free.",
   "Name Drive folders exactly like the tenancy ID (TEN-003) so search always wins."]),
 ("deep-dive-notion-ai.html","ai","Asking GAIA's AI",
  "The workspace answers plain-English questions — and talks to Keplar's delivery agent when you need more.",
  [("Ask anything","\u201cWhich estates have arrears?\u201d &#183; \u201cWhat expires this month?\u201d &#183; \u201cSummarise the dispute.\u201d The AI reads the pages you're allowed to see — nothing more."),
   ("It can also do","Summaries of long pages, first drafts of descriptions, tidy-ups of rough notes."),
   ("The GAIA bridge","Keplar's delivery agent (GAIA) connects to the workspace: it holds the project knowledge, the QA baselines, and answers the AI's harder questions through a secure channel."),
   ("Limits, honestly","AI suggests; verified records decide. Numbers on dashboards never come from the AI.")],
  ["Ask the AI for a Friday digest draft — then check it against the views (practice makes trust).",
   "New staff? Let them ask the AI instead of interrupting the PA.",
   "If an AI answer ever disagrees with a dashboard — the dashboard wins; tell the office."]),
 ("deep-dive-data-care.html","seal","Dummy data, live data &amp; record safety",
  f"Every record wears a label: {pill('warn','DUMMY','seal')} or {pill('ok','LIVE','check')}. That label is a promise.",
  [("Why labels","The system was built and tested on dummy data (the contract requires it). Before real records arrive, the firm gives written approval — then live records flow in, tagged LIVE."),
   ("The golden rules","Live data never leaves the client's workspace. Nothing unverified counts in totals. Corrections happen in the open, tracked by history."),
   ("Your part","Tag correctly, verify before trusting, and never keep shadow copies outside the system.")],
  ["See a number you doubt? Check the record's verification status first.",
   "Keep receipts in Drive, not as screenshots in chats — one home for evidence.",
   "When in doubt about sharing something — ask. One question beats one leak."]),
]

# ------------------------------------------------------------ demo-day + storyboard
def doc_shell(title, sub, body, kicker="Keplar Flow"):
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{esc(title)}</title><style>{CSS}
@media print{{@page{{size:A4;margin:16mm}}}}
</style></head>
<body><div class="wrap">
<header class="site"><div class="brandbar">
  <svg class="brandmark" viewBox="0 0 96 96" aria-hidden="true"><rect width="96" height="96" rx="22" fill="{P['forest']}"/><path d="M65 35.5a19 19 0 1 0 2.5 26.5H55" fill="none" stroke="{P['gold']}" stroke-width="8.5" stroke-linecap="round"/></svg>
  <div><div class="mono" style="color:{P['gold7']};letter-spacing:3px;font-size:12px">{esc(kicker).upper()}</div>
  <h1>{esc(title)}</h1><div class="sub">{sub}</div></div>
</div></header>
{body}<footer><span>GAIA &#183; Gom Chambers &#215; Keplar Flow Limited &#183; 2026-09-19</span>
<span class="mono noprint">print-ready &#183; A4</span></footer>
</div></body></html>"""

AGENDA_ROWS = [
 ("1","0–5","Welcome &amp; agenda","Adebayo + Gom","Alignment on the three goals: UAT demo, team intro, prod kickoff"),
 ("2","5–10","Our ops team","Adebayo","Who does what; single point of contact"),
 ("3","10–35","<b>UAT demo</b> (staging)","Adebayo + Gaia/Notion AI","System working end-to-end on dummy data; UAT A/B/C walked live"),
 ("4","35–45","Q&amp;A / client test cases","All","Client-selected scenarios run on demand"),
 ("5","45–60","<b>PA working model</b> (live intake)","Adebayo + Gom's PA","Intake protocol agreed; weekly rhythm understood"),
 ("6","60–80","<b>Prod kickoff</b> (parallel build)","Adebayo + Gom","Access verified on the Pro workspace; gates restated"),
 ("7","80–90","Wrap: next steps &amp; recap","Adebayo","Recap email same day; acceptance path"),
]
TEAM = [
 ("Emmanuel Adebayo","Founder/CTO, Keplar Flow","Technical Lead; single point of contact; all client-facing comms"),
 ("GAIA delivery agent","Keplar's delivery automation","Built staging + production; runs verification, dashboards, docs"),
 ("Notion AI","Workspace assistant (client plan)","Day-to-day helper post-handover: answers, summaries, guided edits"),
 ("Gom Chambers side","Principal &#183; PA &#183; Legal &#183; Field","Acceptance authority; data intake; portals"),
]
def agenda_html():
    rows = "".join(f"<tr><td class='mono'>{a}</td><td class='mono'>{b}</td><td>{c}</td><td>{d}</td><td>{e}</td></tr>" for a,b,c,d,e in AGENDA_ROWS)
    team = "".join(f"<tr><td><b>{a}</b></td><td>{b}</td><td>{c}</td></tr>" for a,b,c in TEAM)
    body = f"""
<div class="callout c-gold">{icon('calendar',18)} <b>Working title:</b> “From Blueprint to Reality — GAIA UAT Demo &amp; Production Kickoff”.
90 minutes (+30 buffer) &#183; Google Meet (recorded, client consent) &#183; Prerequisite: pre-session checklist complete — esp. the client's pre-created Pro account.</div>
<h2>{icon('clock')}Agenda</h2>
<table style="width:100%;border-collapse:collapse;font-size:14px">
<thead><tr style="text-align:left;color:{P['muted']};font-family:{FONT_MONO};font-size:11px;letter-spacing:1px">
<th style="padding:6px 8px;border-bottom:2px solid {P['line2']}">#</th><th style="padding:6px 8px;border-bottom:2px solid {P['line2']}">MIN</th>
<th style="padding:6px 8px;border-bottom:2px solid {P['line2']}">SEGMENT</th><th style="padding:6px 8px;border-bottom:2px solid {P['line2']}">LEAD</th>
<th style="padding:6px 8px;border-bottom:2px solid {P['line2']}">OUTCOME</th></tr></thead>
<tbody>{rows}</tbody></table>
<h2>{icon('tenants')}The ops team</h2>
<table style="width:100%;border-collapse:collapse;font-size:14px"><tbody>{team}</tbody></table>
<h2>{icon('shield')}Risks &amp; fallbacks</h2>
<div class="card">
<b>Staging quota hiccup mid-demo</b> &#8594; wow-moments 1–7 are quota-independent; front-loaded.<br>
<b>Pro workspace not pre-created</b> &#8594; segment 6 becomes a guided set-up; 1–5 unchanged.<br>
<b>Client test case needs structure change</b> &#8594; log it; classify &#167;3.5-necessary vs &#167;7-change; confirm after.<br>
<b>Live-data questions</b> &#8594; point to the gated path; never improvise authorization on a call.
</div>"""
    return doc_shell("Client Demo &amp; Handover — Session Agenda",
                     "From Blueprint to Reality &#183; 90 minutes &#183; Gom Chambers &#215; Keplar Flow", body, "GAIA &#183; Demo Day")

STOPS = [
 ("1","GAIA Portal","Land. 30s of silence — let the cover, KPI cards and charts speak. <span class='mono'>&#8358;1,800,000 &#183; &#8358;5,055,000 &#183; &#8358;745,000</span>"),
 ("2","The P-014 cascade — the hero moment","Verify &#8358;200,000 &#8594; arrears &#8358;745,000&#8594;&#8358;545,000, Beta 450k&#8594;250k, portfolio 1,045k&#8594;845k. Every screen, same second."),
 ("3","Principal Portal","Escalation queue + rent &amp; expiry calendar + portfolio timeline. \u201cWhen is anything due\u201d — answered."),
 ("4","Calendar &amp; Accountability Hub","Lease ends, task deadlines, payment due dates; responsibility boards. Nothing is unowned."),
 ("5","PA Portal","Pending-verification worklist + triage + cleaning grid — the PA's daily reality."),
 ("6","Legal Portal","Renewal monitor + swimlane timeline + case board (TEN-008 dispute visible)."),
 ("7","Field Portal (phone!) — the fastest wow","Submit a live incident &#8594; it appears in PA triage in front of them. The fastest wow."),
 ("8","Security posture","Backend isolation, role boundaries, the staged hardening page."),
 ("9","Notion AI live","PA asks a natural question; AI answers from the workspace + GAIA bridge."),
 ("10","Permission proof","Open a Field-restricted surface; show \u201cno access\u201d is real."),
]
def onepager_html():
    items = "".join(f"<div class='card' style='padding:12px 16px'><span class='pill p-gold'>{a}</span><b>{b}</b><div style='margin-top:4px;font-size:14px'>{c}</div></div>" for a,b,c in STOPS)
    body = f"""
<div class="callout c-info">{icon('chart',18)} <b>The ten stops</b> — the demo in order. Every expected value is verified dummy-data arithmetic. If any screen deviates, pause and say \u201clet me check that\u201d — never demo a wrong number.</div>
{items}
<div class="callout c-gold" style="margin-top:18px">{icon('check',18)} <b>Close:</b> 6 databases, 53 dummy records, every figure traceable. The staging you watched is the production system, minus your real data.</div>"""
    return doc_shell("GAIA Demo — One Pager", "The ten stops, in order &#183; for the client's hands", body, "GAIA &#183; Demo Day")

CHECK = [
 ("A. Before the email goes out","KF",["Session date confirmed; Meet link created (record consent noted)",
  "Staging demo dry-run completed end-to-end using the demo script (no wrong numbers)",
  "Phone ready for the Field-portal demo (logged into the workspace account)",
  "Session pack printed/second-screened: plan, script, PA protocol, UAT checklist",
  "Recap-email template drafted (fill numbers same day)"]),
 ("B. For Gom — the pre-created Pro account","GC",["Create a new Google account for the firm's Notion admin",
  "Sign up at notion.so &#8594; choose Notion Pro (Plus) — 1 seat to start (billing owned by Gom Chambers)",
  "In that workspace: Settings &#8594; Members &#8594; invite adebayo@keplarflow.com as <b>Admin</b> (not owner — Gom stays single owner, &#167;3.2)",
  "(Day of session, 10 min before) Gom clicks the OAuth consent link Keplar sends, selecting \u201cAll pages\u201d"]),
 ("C. On our side for prod","KF",["Fresh MCP OAuth authorize URL generated + listener armed",
  "build_production.py reviewed; config title set to the prod root name",
  "Tokens/steps rehearsed against staging (dry-run mode)",
  "This machine online + bridges alive; ngrok pair applied if available"]),
 ("D. Session-day, 30 minutes before","KF",["Staging spot-check: P-014 reset to Pending Verification; queues show 745k / 1,045k",
  "Field form test row cleaned; queues tidy",
  "Calendar/timeline views open without quota warnings; Notion AI quota confirmed",
  "Prod invite accepted; workspace reachable",
  "Demo order rehearsed (top-3 stops) once"]),
 ("E. After the session","KF",["Recap email same day: what was demoed, decisions, open items (&#167;3.5 vs &#167;7)",
  "If &#167;3.3 authorization given in writing: schedule live-data intake kickoff with the PA",
  "Prod build log started; UAT checklist running against prod",
  "Session recording + artifacts filed to the client folder"]),
]
def checklist_html():
    secs = ""
    for title, owner, items in CHECK:
        lic = "".join(f"<li>{i}</li>" for i in items)
        secs += (f"<h2>{icon('check')}{title} <span class='pill p-info' style='margin-left:8px'>{owner}</span></h2>"
                 f"<ul class='chk'>{lic}</ul>")
    body = f"""<style>.chk{{list-style:none;margin:6px 0 14px}}
.chk li{{position:relative;padding:8px 0 8px 34px;border-bottom:1px dotted {P['line']};font-size:14.5px}}
.chk li::before{{content:'';position:absolute;left:0;top:10px;width:17px;height:17px;border:1.6px solid {P['line2']};border-radius:5px}}</style>
<div class="callout c-info">{icon('seal',18)} Owner legend: <b>KF</b> Keplar Flow (Adebayo/GAIA) &#183; <b>GC</b> Gom Chambers (Gom/PA). Tick as you go.</div>
{secs}"""
    return doc_shell("Pre-Session Checklist", "Client demo &amp; handover &#183; owner-tagged", body, "GAIA &#183; Demo Day")

def storyboard_html():
    frames = ""
    for no, kicker, headline, vo, motif in CARDS:
        img = f"../assets/cards/gaia-card-{no}.svg"
        frames += f"""
<section class="frame">
  <img src="{img}" alt="Scene {no}: {esc(kicker)}" loading="lazy">
  <div class="meta"><span class="mono">SCENE {no}</span><b>{esc(kicker)}</b><span class="mono">{esc(headline)}</span></div>
  <p>{vo}</p>
</section>"""
    body = f"""<style>
.frames{{display:grid;grid-template-columns:1fr;gap:20px;margin-top:18px}}
.frame{{border:1px solid {P['line']};border-radius:var(--r-lg);overflow:hidden;background:var(--card);box-shadow:var(--sh-1)}}
.frame img{{display:block;width:100%;height:auto}}
.frame .meta{{display:flex;align-items:center;gap:12px;padding:12px 16px 4px;color:{P['forest']}}}
.frame .meta .mono{{color:{P['gold7']};letter-spacing:2px;font-size:12px}}
.frame .meta b{{font-size:16px}}
.frame p{{padding:2px 16px 16px;color:{P['muted']};font-size:14.5px;margin:0}}
@media(min-width:820px){{.frames{{grid-template-columns:1fr 1fr}}.frame:first-child{{grid-column:1/-1}}}}
</style>
<div class="callout c-gold">{icon('chart',18)} <b>9 scenes, ~3:30.</b> Screen-recording + narration. Every number on screen is real dummy-data arithmetic — no mockups; record the actual workspace. Title cards below double as the video's section frames.</div>
<div class="frames">{frames}</div>"""
    return doc_shell("GAIA — Product Video Storyboard", "9 scenes &#183; title cards + narration &#183; “Your property practice, running itself”", body, "GAIA &#183; Storyboard")

# ------------------------------------------------------------ showcase
def showcase_html():
    swatches = [("Forest","forest","Primary brand &#183; headers, rules, primary actions","#0F3D2E"),
                ("Forest Deep","forest9","Depth &#183; gradients, dark surfaces","#0A2A1F"),
                ("Gold","gold","Accent &#183; seals, rules, highlights","#D4A24C"),
                ("Gold Ink","gold7","Accessible gold text on light","#9A742E"),
                ("Blueprint Navy","navy","Secondary accent &#183; legal/technical","#0F2A43"),
                ("Paper","paper","Warm neutral page background","#FBFAF7"),
                ("Ink","ink","Body text","#1F1C16"),
                ("Muted","muted","Secondary text","#5C5648"),
                ("Line","line","Hairline borders","#E2DCCD")]
    sw = "".join(f"<div class='sw'><span class='chip' style='background:{P[k]}'></span>"
                 f"<div><b>{n}</b><div class='mono'>{h}</div><div class='use'>{u}</div></div></div>" for n,k,u,h in swatches)
    sem = [("ok","Verified / secure"),("warn","Attention / pending"),("bad","Arrears / critical"),("info","Informational")]
    semrow = "".join(f"<span class='pill p-{k}'>{icon('check' if k=='ok' else 'notice',12)} {n}</span>" for k,n in sem)
    icons = "".join(f"<div class='ic'{(' title=\"'+k+'\"')}>{icon(k,26)}<span class='mono'>{k}</span></div>" for k in __import__('gcommon').ICONS)
    covers = "".join(f"<figure class='fig'><img src='assets/covers/gaia-cover-{th}.svg' alt='{th} cover' loading='lazy'><figcaption class='mono'>{th}</figcaption></figure>" for th in COVER_THEMES)
    charts = "".join(f"<figure class='fig'><img src='assets/charts/{f}' alt='{f}' loading='lazy'></figure>"
                     for f in ["gaia-chart-arrears-by-estate.svg","gaia-chart-collections.svg","gaia-chart-occupancy.svg"])
    cards = "".join(f"<figure class='fig card-fig'><img src='assets/cards/gaia-card-{no}.svg' alt='card {no}' loading='lazy'></figure>" for no,_,_,_,_ in CARDS)
    body = f"""<style>
.sec{{margin-top:44px}}
.sec > h2{{font-size:24px;border-bottom:2px solid {P['gold']};padding-bottom:8px}}
.lead{{color:{P['muted']};max-width:72ch}}
.swgrid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px;margin-top:16px}}
.sw{{display:flex;gap:14px;align-items:center;padding:12px 14px;border:1px solid {P['line']};border-radius:var(--r-md);background:var(--card)}}
.chip{{width:46px;height:46px;border-radius:10px;border:1px solid {P['line']};flex:none}}
.sw b{{font-size:15px}} .sw .use{{font-size:12.5px;color:{P['muted']}}} .sw .mono{{color:{P['gold7']};font-size:12px}}
.icgrid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));gap:10px;margin-top:16px}}
.ic{{display:flex;flex-direction:column;align-items:center;gap:6px;padding:14px 6px;border:1px solid {P['line']};border-radius:var(--r-md);background:var(--card);color:{P['forest']}}}
.ic span{{font-size:11px;color:{P['muted']}}}
.figgrid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:16px;margin-top:16px}}
.fig{{margin:0;border:1px solid {P['line']};border-radius:var(--r-md);overflow:hidden;background:var(--card)}}
.fig img{{display:block;width:100%;height:auto}} .fig figcaption{{padding:8px 12px;color:{P['muted']};font-size:12px}}
.card-fig{{grid-column:span 2}} @media(max-width:900px){{.card-fig{{grid-column:auto}}}}
.figgrid.widelist{{grid-template-columns:1fr}}
.type-scale .row{{display:flex;align-items:baseline;gap:18px;padding:10px 0;border-bottom:1px dotted {P['line']}}}
.type-scale .tag{{font-family:{FONT_MONO};font-size:11px;color:{P['gold7']};width:130px;flex:none}}
.legal{{font-family:{FONT_LEGAL};}}
.on-dark{{background:{P['forest']};border-radius:var(--r-lg);padding:22px;display:flex;gap:26px;align-items:center;flex-wrap:wrap;margin-top:14px}}
</style>
<div class="callout c-gold">{icon('seal',18)} <b>GAIA Asset Library</b> — the branded, unified kit for every client-facing GAIA artifact.
Locked direction: <b>GAIA Forest</b> + <b>Gold</b> on warm neutrals, blueprint-navy accents. Inter (UI) · JetBrains Mono (IDs) · serif for legal documents only.
Tone: legal-practice formal, warm, plain English — never cute, never cluttered.</div>

<section class="sec"><h2>{icon('seal')}Brand &amp; logo</h2>
<p class="lead">A single seal carries the brand: a gold G on forest with a centred node. Lockups scale from app mark to letterhead. Clearspace = the height of the G's stroke on all sides.</p>
<div style="display:flex;gap:26px;align-items:center;flex-wrap:wrap;margin-top:16px">
  <svg width="72" height="72" viewBox="0 0 96 96"><rect width="96" height="96" rx="22" fill="{P['forest']}"/><path d="M65 35.5a19 19 0 1 0 2.5 26.5H55" fill="none" stroke="{P['gold']}" stroke-width="8.5" stroke-linecap="round"/></svg>
  <svg width="72" height="72" viewBox="0 0 96 96"><rect width="96" height="96" rx="22" fill="{P['gold']}"/><path d="M65 35.5a19 19 0 1 0 2.5 26.5H55" fill="none" stroke="{P['forest']}" stroke-width="8.5" stroke-linecap="round"/></svg>
  <img src="assets/logo/gaia-wordmark.svg" alt="GAIA wordmark" style="height:64px">
</div>
<div class="on-dark">
  <svg width="56" height="56" viewBox="0 0 96 96"><path d="M65 35.5a19 19 0 1 0 2.5 26.5H55" fill="none" stroke="{P['gold']}" stroke-width="8.5" stroke-linecap="round"/></svg>
  <img src="assets/logo/gaia-lockup-reverse.svg" alt="GAIA lockup on dark" style="height:70px">
</div></section>

<section class="sec"><h2>{icon('chart')}Colour</h2>
<p class="lead">Max four semantic colours + one accent. Dominant forest, sharp gold accent — no timid even-spread palettes.</p>
<div class="swgrid">{sw}</div>
<p class="lead" style="margin-top:16px">Semantic states (background / text pairs):</p>
<p>{semrow}</p></section>

<section class="sec"><h2>{icon('document')}Typography</h2>
<p class="lead">Inter is the default — locked by the GAIA brand direction. JetBrains Mono carries IDs and references. A serif is reserved strictly for legal-document artifacts.</p>
<div class="type-scale card">
  <div class="row"><span class="tag">DISPLAY / 800</span><span style="font-size:40px;font-weight:800;color:{P['forest']};letter-spacing:-1px">Every lease, every naira.</span></div>
  <div class="row"><span class="tag">HEADING / 700</span><span style="font-size:24px;font-weight:700;color:{P['forest']}">Which estate carries the risk</span></div>
  <div class="row"><span class="tag">BODY / 400</span><span style="font-size:16px">Only verified money counts in balances, charts and dashboards.</span></div>
  <div class="row"><span class="tag">MONO / IDs</span><span class="mono" style="font-size:15px">TEN-003 &#183; P-014 &#183; REF-DUMMY-014 &#183; &#8358;745,000</span></div>
  <div class="row"><span class="tag">LEGAL SERIF</span><span class="legal" style="font-size:19px">Notice of rent arrears &#8212; drafted, served, logged.</span></div>
</div></section>

<section class="sec"><h2>{icon('units')}Icon set</h2>
<p class="lead">Monochrome line icons, 1.7px stroke, currentColor, 24&#215;24. Six database glyphs plus roles and UI marks. No emoji anywhere in the library.</p>
<div class="icgrid">{icons}</div></section>

<section class="sec"><h2>{icon('chart')}Cover system</h2>
<p class="lead">Five reproducible themes at 3000&#215;1200 (print-ready). A gold spine-rule and seal carry across all of them; each wiki page takes a hero band from the same system.</p>
<div class="figgrid widelist">{covers}</div></section>

<section class="sec"><h2>{icon('chart')}Data plates</h2>
<p class="lead">Chart plates drawn from the frozen QA baseline — arrears by estate (120k / 450k / 475k), collections progress (5,055,000 of 5,800,000), occupancy (6 of 10).</p>
<div class="figgrid">{charts}</div></section>

<section class="sec"><h2>{icon('seal')}Video title cards</h2>
<p class="lead">Nine scene frames for the product video, matching the storyboard.</p>
<div class="figgrid">{cards}</div></section>

<section class="sec"><h2>{icon('arrow')}Applications</h2>
<p class="lead">The system applied to the actual client-facing artifacts:</p>
<div class="links">
<a href="wiki/index.html">{icon('document')}<b>GAIA Onboarding Wiki</b> — 13 branded, self-contained pages with covers + print CSS</a>
<a href="storyboard/V1 GAIA Storyboard.html">{icon('chart')}<b>Video storyboard</b> — 9 scenes, cards + narration</a>
<a href="demo-day/GAIA-Session-Agenda.html">{icon('calendar')}<b>Demo-day pack</b> — agenda, one-pager, checklist (print-ready)</a>
</div></section>"""
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GAIA Asset Library</title><style>{CSS}
.wrap{{--wrap:1080px}}</style></head>
<body><div class="wrap">
<header class="site"><div class="brandbar">
  <svg class="brandmark" viewBox="0 0 96 96" aria-hidden="true" style="width:46px;height:46px"><rect width="96" height="96" rx="22" fill="{P['forest']}"/><path d="M65 35.5a19 19 0 1 0 2.5 26.5H55" fill="none" stroke="{P['gold']}" stroke-width="8.5" stroke-linecap="round"/></svg>
  <div><div class="mono" style="color:{P['gold7']};letter-spacing:3px;font-size:12px">KEPlAR FLOW &#183; CLIENT LIBRARY</div>
  <h1>GAIA Asset Library</h1><div class="sub">Brand system, covers, icons, plates and cards for every GAIA artifact</div></div>
</div></header>
{body}
<footer><span>GAIA &#183; Gom Chambers property operations &#183; Keplar Flow Limited &#183; 2026-09-19</span>
<span class="mono noprint">V1 &#183; locked palette</span></footer>
</div></body></html>"""

# ------------------------------------------------------------ run
def run():
    n = 0
    # wiki
    write_text(os.path.join(W, "index.html"),
               text_page("index", "Welcome to GAIA", "Your guide to working with GAIA — start with your role",
                         "role-principal", index_body, back=None))
    n += 1
    for fname, ic, name, promise, day1, daily, weekly, dives, tips in ROLES:
        write_text(os.path.join(W, fname), role_page(fname, ic, name, promise, day1, daily, weekly, dives, tips)); n += 1
    for fname, ic, title, one, sections, ideas in DIVES:
        write_text(os.path.join(W, fname), dive_page(fname, ic, title, one, sections, ideas)); n += 1
    # demo-day
    write_text(os.path.join(D, "GAIA-Session-Agenda.html"), agenda_html()); n += 1
    write_text(os.path.join(D, "GAIA-Demo-One-Pager.html"), onepager_html()); n += 1
    write_text(os.path.join(D, "GAIA-Checklist.html"), checklist_html()); n += 1
    # storyboard + showcase
    write_text(os.path.join(S, "V1 GAIA Storyboard.html"), storyboard_html()); n += 1
    write_text(os.path.join(KIT, "V1 GAIA Asset Library.html"), showcase_html()); n += 1
    print(f"[pages] wrote {n} files")
    print("wiki:", len(os.listdir(W)), "pages")

if __name__ == "__main__":
    run()
