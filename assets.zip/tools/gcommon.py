# -*- coding: utf-8 -*-
"""GAIA Asset Library - shared foundations (tokens, CSS, icon set, helpers).

Redesign (Refinement) of the GAIA client-facing library, within the locked
brand direction: GAIA Forest #0F3D2E + Gold #D4A24C on warm neutrals #FBFAF7,
blueprint-navy #0F2A43 accents. Inter (UI), JetBrains Mono (IDs/refs),
serif reserved for legal-document artifacts only.
"""
import os

# ----------------------------------------------------------------- palette
P = {
    "forest":   "#0F3D2E", "forest2": "#145038", "forest9": "#0A2A1F", "forest05": "#EAF1ED",
    "gold":     "#D4A24C", "gold3":   "#E4BE7A", "gold7":   "#9A742E", "gold05":  "#FAF2DD",
    "navy":     "#0F2A43", "navy2":   "#153A5C", "navy05":  "#E9EFF5",
    "paper":    "#FBFAF7", "card":    "#FFFFFF", "ink":     "#1F1C16",
    "muted":    "#5C5648", "faint":   "#8A8474", "line":    "#E2DCCD", "line2": "#CFC6B0",
    "ok":       "#EDF3EC", "okt":     "#3E7A57", "okb":     "#448361",
    "warn":     "#FAEBDD", "warnt":   "#C25E0B", "warnb":   "#D9730D",
    "bad":      "#FDEBEC", "badt":    "#C33F3A", "badb":    "#D44E49",
    "info":     "#E7F3F8", "infot":   "#2A6E96", "infob":   "#327DA9",
    "charcoal": "#23211C", "ivory":   "#F4F0E6",
}

FONT_SANS  = "Inter,'Segoe UI',system-ui,-apple-system,'Helvetica Neue',Arial,sans-serif"
FONT_MONO  = "'JetBrains Mono',ui-monospace,SFMono-Regular,Menlo,Consolas,monospace"
FONT_LEGAL = "'Spectral',Georgia,'Times New Roman',serif"

# ----------------------------------------------------------------- core CSS
# font-stack: Inter (per locked GAIA brand direction: Inter default).
CSS = """
:root{
  --forest:#0F3D2E; --forest-2:#145038; --forest-9:#0A2A1F; --forest-05:#EAF1ED;
  --gold:#D4A24C; --gold-3:#E4BE7A; --gold-7:#9A742E; --gold-05:#FAF2DD;
  --navy:#0F2A43; --navy-2:#153A5C; --navy-05:#E9EFF5;
  --paper:#FBFAF7; --card:#FFFFFF; --ink:#1F1C16; --muted:#5C5648; --faint:#8A8474;
  --line:#E2DCCD; --line-2:#CFC6B0;
  --ok:#EDF3EC; --ok-t:#3E7A57; --ok-b:#448361;
  --warn:#FAEBDD; --warn-t:#C25E0B; --warn-b:#D9730D;
  --bad:#FDEBEC; --bad-t:#C33F3A; --bad-b:#D44E49;
  --info:#E7F3F8; --info-t:#2A6E96; --info-b:#327DA9;
  --font-sans:Inter,'Segoe UI',system-ui,-apple-system,'Helvetica Neue',Arial,sans-serif;
  --font-mono:'JetBrains Mono',ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  --font-legal:'Spectral',Georgia,'Times New Roman',serif;
  --sp-1:4px; --sp-2:8px; --sp-3:12px; --sp-4:16px; --sp-5:24px; --sp-6:32px; --sp-7:48px; --sp-8:64px;
  --r-sm:8px; --r-md:12px; --r-lg:16px; --r-xl:22px; --r-pill:999px;
  --sh-1:0 1px 2px rgba(31,28,22,.05),0 1px 3px rgba(31,28,22,.05);
  --sh-2:0 6px 18px -8px rgba(15,61,46,.18),0 2px 6px -2px rgba(31,28,22,.06);
  --sh-3:0 24px 50px -24px rgba(15,61,46,.35);
  --wrap:880px;
}
*{box-sizing:border-box;margin:0;padding:0}
html{-webkit-text-size-adjust:100%}
body{font-family:var(--font-sans);background:var(--paper);color:var(--ink);
     line-height:1.62;font-size:16px;font-feature-settings:"cv11","ss01";}
.wrap{max-width:var(--wrap);margin:0 auto;padding:26px 22px 72px}
a{color:var(--forest-2);text-decoration:none}
a:hover{text-decoration:underline}
.mono{font-family:var(--font-mono);font-size:.86em;letter-spacing:-.01em}
.ico{width:1em;height:1em;display:inline-block;vertical-align:-.14em;fill:none;
     stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
h2{color:var(--forest);font-size:21px;line-height:1.25;margin:30px 0 10px;letter-spacing:-.01em}
h2 .ico{color:var(--gold-7);margin-right:8px;width:1.05em;height:1.05em}
h3{font-size:16px;margin:18px 0 4px;color:var(--forest-9)}
p{margin:9px 0}
b,strong{color:var(--forest-9)}
.card{background:var(--card);border:1px solid var(--line);border-radius:var(--r-md);
      padding:18px 20px;margin:14px 0;box-shadow:var(--sh-1)}
.callout{border-radius:var(--r-md);padding:14px 18px;margin:14px 0;font-size:15px;
         border:1px solid transparent}
.c-ok{background:var(--ok);border-color:#D7E6D6} .c-warn{background:var(--warn);border-color:#F0DBC4}
.c-bad{background:var(--bad);border-color:#F5D2D3} .c-info{background:var(--info);border-color:#CFE3ED}
.c-gold{background:var(--gold-05);border-color:#EDDFB8}
.steps{counter-reset:s;list-style:none;margin:12px 0}
.steps li{counter-increment:s;position:relative;padding:11px 0 11px 48px;border-bottom:1px dotted var(--line)}
.steps li:last-child{border-bottom:none}
.steps li::before{content:counter(s);position:absolute;left:0;top:11px;width:31px;height:31px;
   border-radius:50%;background:var(--forest);color:#fff;font-weight:700;display:flex;
   align-items:center;justify-content:center;font-size:14px;font-family:var(--font-mono)}
.links a{display:block;background:var(--card);border:1px solid var(--line);border-radius:var(--r-md);
   padding:13px 16px;margin:9px 0;color:var(--ink);box-shadow:var(--sh-1);transition:.16s ease}
.links a:hover{border-color:var(--gold);transform:translateY(-2px);box-shadow:var(--sh-2);text-decoration:none}
.links a b{color:var(--forest)}
.links a .ico{color:var(--gold-7);margin-right:8px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px}
.pill{display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:700;
      border-radius:var(--r-pill);padding:3px 11px;margin-right:6px;letter-spacing:.01em}
.pill .ico{width:13px;height:13px;stroke-width:2}
.p-ok{background:var(--ok);color:var(--ok-t)} .p-warn{background:var(--warn);color:var(--warn-t)}
.p-bad{background:var(--bad);color:var(--bad-t)} .p-info{background:var(--info);color:var(--info-t)}
.p-gold{background:var(--gold-05);color:var(--gold-7)}
footer{margin-top:46px;padding-top:15px;border-top:1px solid var(--line);
       color:var(--muted);font-size:12.5px;display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap}
hr.rule{border:none;border-top:1px solid var(--line);margin:26px 0}
/* ---------- brand chrome ---------- */
.brandbar{display:flex;align-items:center;gap:12px}
.brandmark{width:42px;height:42px;flex:none}
header.site{border-bottom:2px solid var(--gold);padding:18px 0 15px;margin-bottom:24px}
header.site h1{font-size:25px;color:var(--forest);letter-spacing:-.02em;line-height:1.15}
header.site .sub{color:var(--muted);font-size:14px;margin-top:2px}
nav.bread{font-size:13px;margin:18px 0 4px;color:var(--muted)}
nav.bread a{color:var(--forest);font-weight:600}
.hero{margin:0 0 24px;border-radius:var(--r-lg);overflow:hidden;box-shadow:var(--sh-2)}
.hero svg{display:block;width:100%;height:auto}
@media print{
  :root{--paper:#fff}
  body{font-size:11.5pt;background:#fff}
  .wrap{max-width:none;padding:0}
  header.site{margin-bottom:14px}
  a{color:var(--forest);text-decoration:none}
  .card,.callout,.links a{box-shadow:none}
  .links a:hover{transform:none}
  nav.bread,footer .noprint{display:none}
  h2{page-break-after:avoid}
  .card,.callout,.steps li{page-break-inside:avoid}
  .hero{box-shadow:none;border:1px solid var(--line)}
}
"""

# ----------------------------------------------------------------- icons
# Monochrome line icons, 24x24, currentColor, 1.7 stroke. No emoji.
ICONS = {
 "estates":'<path d="M3 11l9-7 9 7"/><path d="M5.5 9.6V20h13V9.6"/><path d="M10 20v-5h4v5"/>',
 "units":'<rect x="3.5" y="3.5" width="7" height="7" rx="1.4"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.4"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.4"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.4"/>',
 "tenants":'<circle cx="12" cy="8" r="3.3"/><path d="M5.4 20a6.6 6.6 0 0 1 13.2 0"/>',
 "tenancies":'<path d="M7 3h7l4.5 4.5V21H7z"/><path d="M14 3v4.6h4.5"/><path d="M10 12.5h6M10 16h4"/>',
 "payments":'<rect x="2.5" y="6" width="19" height="12" rx="2.2"/><circle cx="12" cy="12" r="2.7"/><path d="M6 9.4v5.2M18 9.4v5.2"/>',
 "tasks":'<rect x="3.5" y="3.5" width="17" height="17" rx="3.2"/><path d="M8 12.4l2.6 2.6L16.2 9.4"/>',
 "role-principal":'<path d="M4 8.5l4 3.8L12 6l4 6.3 4-3.8V17.5H4z"/><path d="M4 20h16"/>',
 "role-pa":'<circle cx="12" cy="12" r="8.6"/><path d="M15.2 8.8l-2 4.4-4.4 2 2-4.4z"/>',
 "role-legal":'<path d="M12 4v16M6.5 20h11M4 8h16"/><path d="M8.2 8l-2.8 4.6a2.9 2.9 0 0 0 5.6 0z"/><path d="M15.8 8l2.8 4.6a2.9 2.9 0 0 1-5.6 0z"/>',
 "role-field":'<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4l-5 5a1.45 1.45 0 0 0 2.05 2.05l5-5a4 4 0 0 0 5.35-5.35l-2.3 2.3-2.05-2.05z"/>',
 "calendar":'<rect x="3" y="4.6" width="18" height="16" rx="2.6"/><path d="M3 9.4h18M8 3v3.4M16 3v3.4"/>',
 "timeline":'<path d="M3.5 6.5h9M3.5 12h15M3.5 17.5h6"/><circle cx="16.5" cy="6.5" r="2.1"/><circle cx="12.5" cy="17.5" r="2.1"/>',
 "chart":'<path d="M3 20.5h18"/><rect x="4.6" y="11" width="3.2" height="7.6" rx="1"/><rect x="10.4" y="5.2" width="3.2" height="13.4" rx="1"/><rect x="16.2" y="13.4" width="3.2" height="5.2" rx="1"/>',
 "notice":'<path d="M6.2 9.2a5.8 5.8 0 0 1 11.6 0c0 4.6 1.9 5.9 1.9 5.9H4.3s1.9-1.3 1.9-5.9z"/><path d="M10 19.4a2 2 0 0 0 4 0"/>',
 "shield":'<path d="M12 3l7 3v5.2c0 4.4-2.9 7.4-7 9-4.1-1.6-7-4.6-7-9V6z"/><circle cx="12" cy="10.8" r="1.6"/><path d="M12 12.4v2.8"/>',
 "seal":'<path d="M12 3l2.2 1.6 2.7-.3.9 2.6 2.2 1.6-.9 2.5.9 2.5-2.2 1.6-.9 2.6-2.7-.3L12 21l-2.2-1.6-2.7.3-.9-2.6L4 15.5l.9-2.5L4 10.5l2.2-1.6.9-2.6 2.7.3z"/><path d="M8.6 12l2.3 2.3L15.5 9.6"/>',
 "ai":'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M18.5 16.5l.7 1.9 1.9.7-1.9.7-.7 1.9-.7-1.9-1.9-.7 1.9-.7z"/>',
 "link":'<path d="M10 14a3.6 3.6 0 0 0 5.1 0l2.6-2.6a3.6 3.6 0 0 0-5.1-5.1l-1.3 1.3"/><path d="M14 10a3.6 3.6 0 0 0-5.1 0L6.3 12.6a3.6 3.6 0 0 0 5.1 5.1l1.3-1.3"/>',
 "drive":'<path d="M3 7.2A2.2 2.2 0 0 1 5.2 5h3.6l2 2h8A2.2 2.2 0 0 1 21 9.2v7.6A2.2 2.2 0 0 1 18.8 19H5.2A2.2 2.2 0 0 1 3 16.8z"/>',
 "clock":'<circle cx="12" cy="12" r="8.8"/><path d="M12 6.8V12l3.4 2"/>',
 "search":'<circle cx="11" cy="11" r="6.6"/><path d="M20 20l-4.2-4.2"/>',
 "print":'<path d="M6.5 9V3.5h11V9"/><rect x="3" y="9" width="18" height="7.6" rx="2"/><path d="M6.5 14h11v6.5h-11z"/>',
 "download":'<path d="M12 3.5v11"/><path d="M8 11l4 4 4-4"/><path d="M4 20.5h16"/>',
 "arrow":'<path d="M4 12h14"/><path d="M12.5 6.5l5.5 5.5-5.5 5.5"/>',
 "check":'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
 "scale-legal":'<path d="M6 4h12M12 4v16M8 20h8"/><path d="M6 4L4 10h4zM18 4l-2 6h4z"/>',
 "document":'<path d="M7 3h7l4.5 4.5V21H7z"/><path d="M14 3v4.6h4.5"/><path d="M10 13h6M10 16.5h4"/>',
 "key":'<circle cx="8.5" cy="8.5" r="3.8"/><path d="M11.2 11.2L19 19M16 16l1.8-1.8M13.9 13.9l1.8-1.8"/>',
}

def icon(name, size=16, cls="ico", sw=None):
    """Inline SVG for a named icon (stroke=currentColor)."""
    inner = ICONS.get(name, ICONS["seal"])
    st = f' style="stroke-width:{sw}"' if sw else ""
    return (f'<svg class="{cls}" viewBox="0 0 24 24" width="{size}" height="{size}" '
            f'aria-hidden="true" focusable="false"{st}>{inner}</svg>')

def icon_sprite():
    """A standalone <symbol> sprite of the full set."""
    syms = []
    for k, v in ICONS.items():
        syms.append(f'<symbol id="g-{k}" viewBox="0 0 24 24">{v}</symbol>')
    return ('<svg xmlns="http://www.w3.org/2000/svg" style="display:none" '
            'fill="none" stroke="currentColor" stroke-width="1.7" '
            'stroke-linecap="round" stroke-linejoin="round">' + "".join(syms) + "</svg>")

def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

# ----------------------------------------------------------------- files
def write_text(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    return path
